﻿Imports System.Reflection
Module UtilsModule
    Public Function ConvertToDataTable(Of T)(ByVal list As IList(Of T)) As DataTable

        Dim table As New DataTable()

        Dim fields() As PropertyInfo = GetType(T).GetProperties()

        Dim resultFields As New List(Of PropertyInfo)



        For Each field As PropertyInfo In fields

            Dim type = field.PropertyType

            Dim underlyingType = Nullable.GetUnderlyingType(type)

            Dim returnType = type

            If (Not IsNothing(underlyingType)) Then

                returnType = underlyingType

            End If

            If (Not type.FullName.Contains("ICollection")) Then

                resultFields.Add(field)

                table.Columns.Add(field.Name, returnType)

            End If

        Next

        For Each item As T In list

            Dim row As DataRow = table.NewRow()

            For Each field As PropertyInfo In resultFields

                If (IsNothing(field.GetValue(item))) Then

                    row(field.Name) = System.DBNull.Value

                Else

                    row(field.Name) = field.GetValue(item)

                End If

            Next

            table.Rows.Add(row)

        Next

        Return table

    End Function
End Module
