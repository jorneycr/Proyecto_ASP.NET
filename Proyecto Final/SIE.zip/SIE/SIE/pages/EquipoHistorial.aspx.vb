﻿Imports Telerik.Web.UI
Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration
Public Class EquipoHistorial
    Inherits System.Web.UI.Page

    Public Function CargarEquipo() As DataTable

        Using servicio As New Servicios_SIE.Sie_servicesClient

            Dim registros = servicio.ObtenerEquipoHistorial

            Dim data As DataTable = UtilsModule.ConvertToDataTable(registros)

            Return data

        End Using

    End Function

    Public Function CargarArea() As List(Of Servicios_SIE.AreaClase)
        Using sicarContext As New Servicios_SIE.Sie_servicesClient
            Dim registros = (From t In sicarContext.ObtenerArea Order By t.Area Ascending Select t).ToList
            Return registros
        End Using
    End Function

    Public Function CargarDepartamento() As List(Of Servicios_SIE.Departamento)
        Using sicarContext As New Servicios_SIE.Sie_servicesClient
            Dim registros = (From t In sicarContext.ObtenerDepartamento Order By t.departamento Ascending Select t).ToList
            Return registros
        End Using
    End Function

    Public Function CargarTiposCategoria() As List(Of Servicios_SIE.Categoria) 'TipoCarretaService.TipoCarretaDC
        Using sicarContext As New Servicios_SIE.Sie_servicesClient '("BasicHttpBinding_ICategoria") 'TipoCarretaService.TipoCarretaServiceClient("BasicHttpBinding_ITipoCarretaService")
            Dim registros = (From t In sicarContext.ObtenerCategorias Order By t.categoria Ascending Select t).ToList
            Return registros
        End Using
    End Function

    'Public Function CargarEmpleado() As List(Of Servicios_SIE.Empleado) 'TipoCarretaService.TipoCarretaDC
    '    Using sicarContext As New Servicios_SIE.Sie_servicesClient '("BasicHttpBinding_ICategoria") 'TipoCarretaService.TipoCarretaServiceClient("BasicHttpBinding_ITipoCarretaService")
    '        Dim registros = (From t In sicarContext.ObtenerEmpleado Order By t.empleado Ascending Select t).ToList
    '        Return registros
    '    End Using
    'End Function

    'Public Function CargarDepartamento() As List(Of Servicios_SIE.Departamento) 'TipoCarretaService.TipoCarretaDC
    '    Using sicarContext As New Servicios_SIE.Sie_servicesClient '("BasicHttpBinding_ICategoria") 'TipoCarretaService.TipoCarretaServiceClient("BasicHttpBinding_ITipoCarretaService")
    '        Dim registros = (From t In sicarContext.ObtenerDepartamento Order By t.departamento Ascending Select t).ToList
    '        Return registros
    '    End Using
    'End Function

    Public Function CargarBeneficiarios1() As DataTable

        Using sicarContext As New Servicios_SIE.Sie_servicesClient '("BasicHttpBinding_IProductorService")

            Dim registros = sicarContext.ObtenerEmpleado.ToList()

            Dim data As DataTable = UtilsModule.ConvertToDataTable(registros)

            Return data

        End Using

    End Function

    Public Function GetNombreBeneficiario(valor As Object) As String

        GetNombreBeneficiario = ""

        If (Not IsNothing(valor) And Not IsDBNull(valor)) Then

            Try

                Using sicarContext As New Servicios_SIE.Sie_servicesClient '("BasicHttpBinding_IPropietarioService")

                    GetNombreBeneficiario = sicarContext.ObtenerEmpleadoPorNombre(valor)

                End Using

            Catch ex As Exception

            End Try

        End If

    End Function

    'Public Function CargarDepartamento1() As DataTable

    '    Using sicarContext As New Servicios_SIE.Sie_servicesClient '("BasicHttpBinding_IProductorService")

    '        Dim registros = sicarContext.ObtenerDepartamento.ToList()

    '        Dim data As DataTable = UtilsModule.ConvertToDataTable(registros)

    '        Return data

    '    End Using

    'End Function

    'Public Function GetNombreDepartamento(valor As Object) As String

    '    GetNombreDepartamento = ""

    '    If (Not IsNothing(valor) And Not IsDBNull(valor)) Then

    '        Try

    '            Using sicarContext As New Servicios_SIE.Sie_servicesClient '("BasicHttpBinding_IPropietarioService")

    '                GetNombreDepartamento = sicarContext.ObtenerDepartamentoPorNombre(valor)

    '            End Using

    '        Catch ex As Exception

    '        End Try

    '    End If

    'End Function

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

End Class