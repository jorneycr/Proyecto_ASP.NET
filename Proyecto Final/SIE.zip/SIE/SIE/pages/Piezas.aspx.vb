﻿Imports Microsoft.VisualBasic

Imports Telerik.Web.UI

Imports System.Linq

Public Class Piezas
    Inherits System.Web.UI.Page

    Private Sub DisplayMessage(text As String)

        dtgPiezas.Controls.Add(New LiteralControl(String.Format("<span style='color:red'>{0}</span>", text)))

    End Sub

    Private Sub SetMessage(message As String)

        gridMessage = message

    End Sub


    Private gridMessage As String = Nothing

    Public Sub llamarAgregar()
        MsgBox("Prueba")
        ' Me.dtgPiezas.MasterTableView.CommandItemSettings.AddNewRecordText = "Agregar"
    End Sub

    Public Function CargarTipoPieza() As DataTable

        Using servicio As New Servicios_SIE.Sie_servicesClient

            Dim registros = servicio.ObtenerPieza

            Dim data As DataTable = UtilsModule.ConvertToDataTable(registros)

            Return data

        End Using

    End Function

    Public Function CargarNombreEquipo() As List(Of Servicios_SIE.Equipo) 'TipoCarretaService.TipoCarretaDC
        Using sicarContext As New Servicios_SIE.Sie_servicesClient '("BasicHttpBinding_ICategoria") 'TipoCarretaService.TipoCarretaServiceClient("BasicHttpBinding_ITipoCarretaService")
            Dim registros = (From t In sicarContext.ObtenerEquipo Order By t.service_tag Ascending Select t).ToList
            Return registros
        End Using
    End Function

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub dtgPiezas_ItemCreated(sender As Object, e As Telerik.Web.UI.GridItemEventArgs)
        If ((TypeOf e.Item Is GridEditFormItem) And e.Item.IsInEditMode) Then

            Dim item As GridEditFormItem = TryCast(e.Item, GridEditFormItem)

            SetFocus(item("Categoria").Controls(0).ClientID)

        End If
        If TypeOf e.Item Is GridEditableItem AndAlso e.Item.IsInEditMode Then

            If Not (TypeOf e.Item Is GridEditFormInsertItem) Then

                Dim item As GridEditableItem = TryCast(e.Item, GridEditableItem)

                Dim manager As GridEditManager = item.EditManager

                Dim editor As GridTextBoxColumnEditor = TryCast(manager.GetColumnEditor("Numero_pieza"), GridTextBoxColumnEditor)

                editor.TextBoxControl.Enabled = False

                Dim Categoria As GridTextBoxColumnEditor = TryCast(manager.GetColumnEditor("Categoria"), GridTextBoxColumnEditor)

                Dim Nombre As GridTextBoxColumnEditor = TryCast(manager.GetColumnEditor("Nombre"), GridTextBoxColumnEditor)

                Dim Descripcion As GridTextBoxColumnEditor = TryCast(manager.GetColumnEditor("Descripcion"), GridTextBoxColumnEditor)


                SetFocus(Categoria.TextBoxControl.ClientID)

            End If

        End If
    End Sub

    Protected Sub dtgPiezas_ItemInserted(sender As Object, e As Telerik.Web.UI.GridInsertedEventArgs)
        If e.Exception IsNot Nothing Then

            e.ExceptionHandled = True

            SetMessage("La pieza no pudo ser insertado. Razón: " + e.Exception.Message)

        Else

            SetMessage("La pieza fue insertada!")

        End If
    End Sub

    Protected Sub dtgPiezas_PreRender(sender As Object, e As EventArgs)
        If Not String.IsNullOrEmpty(gridMessage) Then

            DisplayMessage(gridMessage)

        End If
    End Sub

    Private Sub dtgPiezas_DeleteCommand(sender As Object, e As GridCommandEventArgs) Handles dtgPiezas.DeleteCommand
        Dim editedItem As GridEditableItem = TryCast(e.Item, GridEditableItem)

        Dim codigo As Integer = DirectCast(editedItem.GetDataKeyValue("Numero_pieza"), Integer)

        Using servicio As New Servicios_SIE.Sie_servicesClient
            Dim resultado As String = Convert.ToString(servicio.EliminarPieza(codigo))

            If (resultado.Equals("")) Then

                editedItem.Edit = False

                SetMessage("No se puedo eliminar la pieza")

                dtgPiezas.DataBind()

            Else

                SetMessage("Pieza eliminada con éxito")

            End If
        End Using

    End Sub

    Public Sub dtgPiezas_InsertCommand(sender As Object, e As GridCommandEventArgs) Handles dtgPiezas.InsertCommand

        Dim editedItem As GridEditableItem = TryCast(e.Item, GridEditableItem)

        Dim Categoria As TextBox = DirectCast(editedItem("Categoria").Controls(0), TextBox)

        Dim Nombre As TextBox = DirectCast(editedItem("Nombre").Controls(0), TextBox)

        Dim Descripcion As TextBox = DirectCast(editedItem("Descripcion").Controls(0), TextBox)

        Using servicio As New Servicios_SIE.Sie_servicesClient

            'Dim nuevoRegistro As New Servicios_SIE.Categoria With {
            '    .Numero_categoria = 0,
            '    .Categoria = categoria.Text
            '}
            Dim agregarRegistro As New Servicios_SIE.Piezas
            agregarRegistro.categoria = Categoria.Text
            agregarRegistro.nombre = Nombre.Text
            agregarRegistro.descripcion = Descripcion.Text
            agregarRegistro.usuario_creacion = "jorney"
            agregarRegistro.fecha_creacion = Date.Now

            Dim resultado = servicio.InsertarPieza(agregarRegistro)
            If resultado.exito Then

            End If

            If (resultado.Equals("")) Then

                SetMessage("No se pudo insertar la pieza")

                editedItem.Edit = False

                dtgPiezas.DataBind()

            Else

                SetMessage("La pieza insertada con éxito")

            End If

        End Using

    End Sub

    Private Sub dtgPiezas_UpdateCommand(sender As Object, e As GridCommandEventArgs) Handles dtgPiezas.UpdateCommand

        Dim editedItem As GridEditableItem = TryCast(e.Item, GridEditableItem)

        Dim Numero_pieza As Integer = DirectCast(editedItem.GetDataKeyValue("Numero_pieza"), Integer)

        Dim Categoria As TextBox = DirectCast(editedItem("Categoria").Controls(0), TextBox)

        Dim Nombre As TextBox = DirectCast(editedItem("Nombre").Controls(0), TextBox)


        Dim Descripcion As TextBox = DirectCast(editedItem("Descripcion").Controls(0), TextBox)

        Using servicio As New Servicios_SIE.Sie_servicesClient

            'Dim modificarRegistro As New Servicios_SIE.Categoria With {
            '    .numero_categoria = Numero_categoria,
            '    .categoria = categoria.Text,
            '    .usuario_modificacion = "Daniel",
            '    .fecha_modificacion = Date.Now
            '}
            Dim modificarRegistro As New Servicios_SIE.Piezas
            modificarRegistro.numero_pieza = Numero_pieza
            modificarRegistro.categoria = Categoria.Text
            modificarRegistro.nombre = Nombre.Text
            modificarRegistro.descripcion = Descripcion.Text
            modificarRegistro.usuario_modificacion = "Daniel"
            modificarRegistro.fecha_modificacion = Date.Now


            Dim resultado = servicio.ModificarPieza(modificarRegistro)
            If resultado.exito Then

            End If

        End Using


    End Sub

End Class