﻿Imports Telerik.Web.UI

Public Class Departamento
    Inherits System.Web.UI.Page

    Private Sub DisplayMessage(text As String)

        dtgDepar.Controls.Add(New LiteralControl(String.Format("<span style='color:red'>{0}</span>", text)))

    End Sub

    Private Sub SetMessage(message As String)

        gridMessage = message

    End Sub

    Private gridMessage As String = Nothing

    Public Function CargarDepartamento() As DataTable

        Using servicio As New Servicios_SIE.Sie_servicesClient

            Dim registros = servicio.ObtenerDepartamento

            Dim data As DataTable = UtilsModule.ConvertToDataTable(registros)

            Return data

        End Using

    End Function
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub dtgDepar_ItemCreated(sender As Object, e As Telerik.Web.UI.GridItemEventArgs)

        If ((TypeOf e.Item Is GridEditFormItem) And e.Item.IsInEditMode) Then

            Dim item As GridEditFormItem = TryCast(e.Item, GridEditFormItem)

            SetFocus(item("Departamento").Controls(0).ClientID)

        End If
        If TypeOf e.Item Is GridEditableItem AndAlso e.Item.IsInEditMode Then

            If Not (TypeOf e.Item Is GridEditFormInsertItem) Then

                Dim item As GridEditableItem = TryCast(e.Item, GridEditableItem)

                Dim manager As GridEditManager = item.EditManager

                Dim editor As GridTextBoxColumnEditor = TryCast(manager.GetColumnEditor("Numero_departamento"), GridTextBoxColumnEditor)

                editor.TextBoxControl.Enabled = False

                Dim Departamento As GridTextBoxColumnEditor = TryCast(manager.GetColumnEditor("Departamento"), GridTextBoxColumnEditor)



                SetFocus(Departamento.TextBoxControl.ClientID)

            End If

        End If
    End Sub

    Protected Sub dtgDepar_ItemInserted(sender As Object, e As Telerik.Web.UI.GridInsertedEventArgs)
        If e.Exception IsNot Nothing Then

            e.ExceptionHandled = True

            SetMessage("El departamento no pudo ser insertado. Razón: " + e.Exception.Message)

        Else

            SetMessage("El departamento fue insertada!")

        End If
    End Sub

    Protected Sub dtgDepar_PreRender(sender As Object, e As EventArgs)
        If Not String.IsNullOrEmpty(gridMessage) Then

            DisplayMessage(gridMessage)

        End If
    End Sub

    Private Sub dtgDepar_DeleteCommand(sender As Object, e As GridCommandEventArgs) Handles dtgDepar.DeleteCommand
        Dim editedItem As GridEditableItem = TryCast(e.Item, GridEditableItem)

        Dim codigo As Integer = DirectCast(editedItem.GetDataKeyValue("Numero_departamento"), Integer)

        Using servicio As New Servicios_SIE.Sie_servicesClient
            Dim resultado = servicio.EliminarDepartamento(codigo)

            If (resultado.exito = True) Then
                SetMessage("Departamento eliminado con éxito")


            Else
                editedItem.Edit = False

                SetMessage("No se puedo eliminar el Departamento")

                dtgDepar.DataBind()

            End If
        End Using

    End Sub

    Private Sub dtgDepar_InsertCommand(sender As Object, e As GridCommandEventArgs) Handles dtgDepar.InsertCommand

        Dim editedItem As GridEditableItem = TryCast(e.Item, GridEditableItem)

        Dim Departamento As TextBox = DirectCast(editedItem("Departamento").Controls(0), TextBox)


        Using servicio As New Servicios_SIE.Sie_servicesClient

            'Dim nuevoRegistro As New Servicios_SIE.Categoria With {
            '    .Numero_categoria = 0,
            '    .Categoria = categoria.Text
            '}
            Dim agregarRegistro As New Servicios_SIE.Departamento
            agregarRegistro.departamento = Departamento.Text
            agregarRegistro.usuario_creacion = User.Identity.Name
            agregarRegistro.fecha_creacion = Date.Now

            Dim resultado = servicio.InsertarDepartamento(agregarRegistro)
            If resultado.exito Then
                SetMessage("El Departamento insertada con éxito")
            Else
                SetMessage("No se pudo insertar el Departamento")

                editedItem.Edit = False

                dtgDepar.DataBind()
            End If


        End Using

    End Sub

    Private Sub dtgDepar_UpdateCommand(sender As Object, e As GridCommandEventArgs) Handles dtgDepar.UpdateCommand

        Dim editedItem As GridEditableItem = TryCast(e.Item, GridEditableItem)

        Dim Numero_departamento As Integer = DirectCast(editedItem.GetDataKeyValue("Numero_departamento"), Integer)

        Dim Departamento As TextBox = DirectCast(editedItem("Departamento").Controls(0), TextBox)

        Using servicio As New Servicios_SIE.Sie_servicesClient

            'Dim modificarRegistro As New Servicios_SIE.Categoria With {
            '    .numero_categoria = Numero_categoria,
            '    .categoria = categoria.Text,
            '    .usuario_modificacion = "Daniel",
            '    .fecha_modificacion = Date.Now
            '}
            Dim modificarRegistro As New Servicios_SIE.Departamento
            modificarRegistro.numero_departamento = Numero_departamento
            modificarRegistro.departamento = Departamento.Text
            modificarRegistro.usuario_modificacion = User.Identity.Name
            modificarRegistro.fecha_modificacion = Date.Now


            Dim resultado = servicio.ModificarDepartamento(modificarRegistro)
            If resultado.exito = True Then
                SetMessage("El Departamento actualizado con éxito")
            Else
                SetMessage("No se pudo actualizar el Departamento")

                editedItem.Edit = False

                dtgDepar.DataBind()
            End If

        End Using


    End Sub

End Class