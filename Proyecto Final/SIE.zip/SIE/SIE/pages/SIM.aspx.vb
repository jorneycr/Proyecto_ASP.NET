﻿Imports Telerik.Web.UI

Public Class SIM
    Inherits System.Web.UI.Page

    Private Sub DisplayMessage(text As String)

        dtgSIM.Controls.Add(New LiteralControl(String.Format("<span style='color:red'>{0}</span>", text)))

    End Sub

    Private Sub SetMessage(message As String)

        gridMessage = message

    End Sub

    Private gridMessage As String = Nothing

    Public Function CargarSIM() As DataTable

        Using servicio As New Servicios_SIE.Sie_servicesClient

            Dim registros = servicio.ObtenerSIM

            Dim data As DataTable = UtilsModule.ConvertToDataTable(registros)

            Return data

        End Using

    End Function


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub dtgSIM_ItemCreated(sender As Object, e As Telerik.Web.UI.GridItemEventArgs)
        If ((TypeOf e.Item Is GridEditFormItem) And e.Item.IsInEditMode) Then

            Dim item As GridEditFormItem = TryCast(e.Item, GridEditFormItem)

            SetFocus(item("Asignado").Controls(0).ClientID)

        End If
        If TypeOf e.Item Is GridEditableItem AndAlso e.Item.IsInEditMode Then

            If Not (TypeOf e.Item Is GridEditFormInsertItem) Then

                Dim item As GridEditableItem = TryCast(e.Item, GridEditableItem)

                Dim manager As GridEditManager = item.EditManager

                Dim editor As GridTextBoxColumnEditor = TryCast(manager.GetColumnEditor("Numero_SIM"), GridTextBoxColumnEditor)

                editor.TextBoxControl.Enabled = False

                Dim Asignado As GridTextBoxColumnEditor = TryCast(manager.GetColumnEditor("Asignado"), GridTextBoxColumnEditor)


                SetFocus(Asignado.TextBoxControl.ClientID)

                Dim Numero_Telefono As GridTextBoxColumnEditor = TryCast(manager.GetColumnEditor("Numero_Telefono"), GridTextBoxColumnEditor)

                Dim Numero_Serie As GridTextBoxColumnEditor = TryCast(manager.GetColumnEditor("Numero_Serie"), GridTextBoxColumnEditor)

                Dim Pin As GridTextBoxColumnEditor = TryCast(manager.GetColumnEditor("Pin"), GridTextBoxColumnEditor)

                Dim Punk As GridTextBoxColumnEditor = TryCast(manager.GetColumnEditor("Punk"), GridTextBoxColumnEditor)


            End If

        End If
    End Sub

    Protected Sub dtgSIM_ItemInserted(sender As Object, e As Telerik.Web.UI.GridInsertedEventArgs)
        If e.Exception IsNot Nothing Then

            e.ExceptionHandled = True

            SetMessage("La SIM no pudo ser insertado. Razón: " + e.Exception.Message)

        Else

            SetMessage("El area fue insertada!")

        End If
    End Sub

    Protected Sub dtgSIM_PreRender(sender As Object, e As EventArgs)
        If Not String.IsNullOrEmpty(gridMessage) Then

            DisplayMessage(gridMessage)

        End If
    End Sub

    Private Sub dtgSIM_DeleteCommand(sender As Object, e As GridCommandEventArgs) Handles dtgSIM.DeleteCommand
        Dim editedItem As GridEditableItem = TryCast(e.Item, GridEditableItem)

        Dim codigo As Integer = DirectCast(editedItem.GetDataKeyValue("Numero_SIM"), Integer)

        Using servicio As New Servicios_SIE.Sie_servicesClient
            Dim resultado = servicio.EliminarSIM(codigo)

            If (resultado.exito = True) Then

                SetMessage("SIM eliminada con éxito")

            Else

                editedItem.Edit = False

                SetMessage("No se puedo eliminar el SIM")

                dtgSIM.DataBind()

            End If
        End Using

    End Sub

    Private Sub dtgSIM_InsertCommand(sender As Object, e As GridCommandEventArgs) Handles dtgSIM.InsertCommand

        Dim editedItem As GridEditableItem = TryCast(e.Item, GridEditableItem)

        Dim Asignado As TextBox = DirectCast(editedItem("Asignado").Controls(0), TextBox)

        Dim Numero_Telefono As TextBox = DirectCast(editedItem("Numero_Telefono").Controls(0), TextBox)

        Dim Numero_Serie As TextBox = DirectCast(editedItem("Numero_Serie").Controls(0), TextBox)

        Dim Pin As TextBox = DirectCast(editedItem("Pin").Controls(0), TextBox)

        Dim Punk As TextBox = DirectCast(editedItem("Punk").Controls(0), TextBox)



        Using servicio As New Servicios_SIE.Sie_servicesClient

            'Dim nuevoRegistro As New Servicios_SIE.Categoria With {
            '    .Numero_categoria = 0,
            '    .Categoria = categoria.Text
            '}
            Dim agregarRegistro As New Servicios_SIE.SIM
            agregarRegistro.asignado = Asignado.Text
            agregarRegistro.numero_telefono = Numero_Telefono.Text
            agregarRegistro.numero_serie = Numero_Serie.Text
            agregarRegistro.pin = Pin.Text
            agregarRegistro.punk = Punk.Text
            agregarRegistro.usuario_creacion = User.Identity.Name
            agregarRegistro.fecha_creacion = Date.Now

            Dim resultado = servicio.InsertarSIM(agregarRegistro)
            If resultado.exito = True Then
                SetMessage("El SIM insertado con éxito")
            Else

                SetMessage("No se pudo insertar el SIM")

                editedItem.Edit = False

                dtgSIM.DataBind()
            End If


        End Using

    End Sub

    Private Sub dtgSIM_UpdateCommand(sender As Object, e As GridCommandEventArgs) Handles dtgSIM.UpdateCommand

        Dim editedItem As GridEditableItem = TryCast(e.Item, GridEditableItem)

        Dim Numero_SIM As Integer = DirectCast(editedItem.GetDataKeyValue("Numero_SIM"), Integer)

        Dim Asignado As TextBox = DirectCast(editedItem("Asignado").Controls(0), TextBox)

        Dim Numero_Telefono As TextBox = DirectCast(editedItem("Numero_Telefono").Controls(0), TextBox)

        Dim Numero_Serie As TextBox = DirectCast(editedItem("Numero_Serie").Controls(0), TextBox)

        Dim Pin As TextBox = DirectCast(editedItem("Pin").Controls(0), TextBox)

        Dim Punk As TextBox = DirectCast(editedItem("Punk").Controls(0), TextBox)

        Using servicio As New Servicios_SIE.Sie_servicesClient

            'Dim modificarRegistro As New Servicios_SIE.Categoria With {
            '    .numero_categoria = Numero_categoria,
            '    .categoria = categoria.Text,
            '    .usuario_modificacion = "Daniel",
            '    .fecha_modificacion = Date.Now
            '}
            Dim modificarRegistro As New Servicios_SIE.SIM
            modificarRegistro.numero_sim = Numero_SIM
            modificarRegistro.asignado = Asignado.Text
            modificarRegistro.numero_telefono = Numero_Telefono.Text
            modificarRegistro.numero_serie = Numero_Serie.Text
            modificarRegistro.pin = Pin.Text
            modificarRegistro.punk = Punk.Text
            modificarRegistro.usuario_modificacion = User.Identity.Name
            modificarRegistro.fecha_modificacion = Date.Now


            Dim resultado = servicio.ModificarSIM(modificarRegistro)
            If resultado.exito = True Then
                SetMessage("El SIM actualizado con éxito")
            Else
                SetMessage("No se pudo actualizar el SIM")

                editedItem.Edit = False

                dtgSIM.DataBind()
            End If

        End Using


    End Sub

End Class