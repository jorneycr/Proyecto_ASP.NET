﻿Imports Microsoft.VisualBasic

Imports Telerik.Web.UI

Imports System.Linq

Public Class Categoria

    Inherits System.Web.UI.Page



    Private Sub DisplayMessage(text As String)

        dtgCategorias.Controls.Add(New LiteralControl(String.Format("<span style='color:red'>{0}</span>", text)))

    End Sub

    Private Sub SetMessage(message As String)

        gridMessage = message

    End Sub


    Private gridMessage As String = Nothing


    Public Function CargarCategoria() As DataTable

        Using servicio As New Servicios_SIE.Sie_servicesClient

            Dim registros = servicio.ObtenerCategorias

            Dim data As DataTable = UtilsModule.ConvertToDataTable(registros)

            Return data

        End Using

    End Function




    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub dtgCategorias_ItemInserted(sender As Object, e As GridInsertedEventArgs)
        If e.Exception IsNot Nothing Then

            e.ExceptionHandled = True

            SetMessage("La categoria no pudo ser insertado. Razón: " + e.Exception.Message)

        Else

            SetMessage("La Categoria fue insertado!")

        End If
    End Sub

    Protected Sub dtgCategorias_PreRender(sender As Object, e As EventArgs)
        If Not String.IsNullOrEmpty(gridMessage) Then

            DisplayMessage(gridMessage)

        End If
    End Sub

    Protected Sub dtgCategorias_ItemCreated(sender As Object, e As GridItemEventArgs)
        If ((TypeOf e.Item Is GridEditFormItem) And e.Item.IsInEditMode) Then

            Dim item As GridEditFormItem = TryCast(e.Item, GridEditFormItem)

            SetFocus(item("Categoria").Controls(0).ClientID)

        End If
        If TypeOf e.Item Is GridEditableItem AndAlso e.Item.IsInEditMode Then

            If Not (TypeOf e.Item Is GridEditFormInsertItem) Then

                Dim item As GridEditableItem = TryCast(e.Item, GridEditableItem)

                Dim manager As GridEditManager = item.EditManager

                Dim editor As GridTextBoxColumnEditor = TryCast(manager.GetColumnEditor("Numero_categoria"), GridTextBoxColumnEditor)

                editor.TextBoxControl.Enabled = False


                Dim categoria As GridTextBoxColumnEditor = TryCast(manager.GetColumnEditor("Categoria"), GridTextBoxColumnEditor)


                SetFocus(categoria.TextBoxControl.ClientID)

            End If

        End If
    End Sub

    Private Sub dtgCategorias_DeleteCommand(sender As Object, e As GridCommandEventArgs) Handles dtgCategorias.DeleteCommand
        Dim editedItem As GridEditableItem = TryCast(e.Item, GridEditableItem)

        Dim codigo As Integer = DirectCast(editedItem.GetDataKeyValue("Numero_categoria"), Integer)

        Using servicio As New Servicios_SIE.Sie_servicesClient
            Dim resultado = servicio.EliminarCategoria(codigo)

            If (resultado.exito = True) Then
                SetMessage("Categoria eliminada con éxito")


            Else
                editedItem.Edit = False

                SetMessage("No se puedo eliminar la categoria")

                dtgCategorias.DataBind()

            End If
        End Using

    End Sub

    Private Sub dtgCategorias_InsertCommand(sender As Object, e As GridCommandEventArgs) Handles dtgCategorias.InsertCommand

        Dim editedItem As GridEditableItem = TryCast(e.Item, GridEditableItem)

        Dim categoria As TextBox = DirectCast(editedItem("Categoria").Controls(0), TextBox)

        Using servicio As New Servicios_SIE.Sie_servicesClient



            'Dim nuevoRegistro As New Servicios_SIE.Categoria With {
            '    .Numero_categoria = 0,
            '    .Categoria = categoria.Text
            '}
            Dim agregarRegistro As New Servicios_SIE.Categoria
            agregarRegistro.categoria = categoria.Text
            agregarRegistro.usuario_creacion = User.Identity.Name
            agregarRegistro.fecha_creacion = Date.Now

            Dim resultado = servicio.InsertarCategoria(agregarRegistro)
            If resultado.exito Then
                SetMessage("La categoria insertada con éxito")
            Else
                SetMessage("No se pudo insertar la categoria")

                editedItem.Edit = False

                dtgCategorias.DataBind()
            End If


        End Using

    End Sub

    Private Sub dtgCategorias_UpdateCommand(sender As Object, e As GridCommandEventArgs) Handles dtgCategorias.UpdateCommand

        Dim editedItem As GridEditableItem = TryCast(e.Item, GridEditableItem)

        Dim Numero_categoria As Integer = DirectCast(editedItem.GetDataKeyValue("Numero_categoria"), Integer)

        Dim categoria As TextBox = DirectCast(editedItem("Categoria").Controls(0), TextBox)

        Using servicio As New Servicios_SIE.Sie_servicesClient

            'Dim modificarRegistro As New Servicios_SIE.Categoria With {
            '    .numero_categoria = Numero_categoria,
            '    .categoria = categoria.Text,
            '    .usuario_modificacion = "Daniel",
            '    .fecha_modificacion = Date.Now
            '}
            Dim modificarRegistro As New Servicios_SIE.Categoria
            modificarRegistro.numero_categoria = Numero_categoria
            modificarRegistro.categoria = categoria.Text
            modificarRegistro.usuario_modificacion = User.Identity.Name
            modificarRegistro.fecha_modificacion = Date.Now


            Dim resultado = servicio.ModificarCategoria(modificarRegistro)
            If resultado.exito Then
                SetMessage("La categoria actuzalizada con éxito")
            Else
                SetMessage("No se pudo actualizar la categoría")

                editedItem.Edit = False

                dtgCategorias.DataBind()
            End If

        End Using


    End Sub



End Class