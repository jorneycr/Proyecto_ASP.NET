﻿Imports Telerik.Web.UI

Public Class EquipoPiezas
    Inherits System.Web.UI.Page

    Private Sub DisplayMessage(text As String)

        dtgEquipoPiezas.Controls.Add(New LiteralControl(String.Format("<span style='color:red'>{0}</span>", text)))

    End Sub

    Private Sub SetMessage(message As String)

        gridMessage = message

    End Sub

    Public Function CargarNombreEquipo() As List(Of Servicios_SIE.Equipo) 'TipoCarretaService.TipoCarretaDC
        Using sicarContext As New Servicios_SIE.Sie_servicesClient '("BasicHttpBinding_ICategoria") 'TipoCarretaService.TipoCarretaServiceClient("BasicHttpBinding_ITipoCarretaService")
            Dim registros = (From t In sicarContext.ObtenerEquipo Order By t.service_tag Ascending Select t).ToList
            Return registros
        End Using
    End Function

    Public Function CargarNombrePieza() As List(Of Servicios_SIE.Piezas) 'TipoCarretaService.TipoCarretaDC
        Using sicarContext As New Servicios_SIE.Sie_servicesClient '("BasicHttpBinding_ICategoria") 'TipoCarretaService.TipoCarretaServiceClient("BasicHttpBinding_ITipoCarretaService")
            Dim registros = (From t In sicarContext.ObtenerPieza Order By t.nombre Ascending Select t).ToList
            Return registros
        End Using
    End Function

    Public Function CargarEquipoPieza() As DataTable

        Using servicio As New Servicios_SIE.Sie_servicesClient

            Dim registros = servicio.ObtenerEquipoPiezas

            Dim data As DataTable = UtilsModule.ConvertToDataTable(registros)

            Return data

        End Using

    End Function

    Private gridMessage As String = Nothing

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub dtgEquipoPiezas_ItemCreated(sender As Object, e As Telerik.Web.UI.GridItemEventArgs)
        If ((TypeOf e.Item Is GridEditFormItem) And e.Item.IsInEditMode) Then

            Dim item As GridEditFormItem = TryCast(e.Item, GridEditFormItem)

            'SetFocus(item("Categoria").Controls(0).ClientID)

        End If
        If TypeOf e.Item Is GridEditableItem AndAlso e.Item.IsInEditMode Then

            If Not (TypeOf e.Item Is GridEditFormInsertItem) Then

                Dim item As GridEditableItem = TryCast(e.Item, GridEditableItem)

                Dim manager As GridEditManager = item.EditManager

                Dim editor As GridTextBoxColumnEditor = TryCast(manager.GetColumnEditor("numero_equipo_piezas"), GridTextBoxColumnEditor)

                editor.TextBoxControl.Enabled = False

                Dim Numero_Equipo As GridDropDownColumnEditor = TryCast(manager.GetColumnEditor("Numero_Equipo"), GridDropDownColumnEditor)

                Dim Numero_Pieza As GridDropDownColumnEditor = TryCast(manager.GetColumnEditor("Numero_Pieza"), GridDropDownColumnEditor)

                'SetFocus(Numero_Equipo.TextBoxControl.ClientID)

            End If

        End If
    End Sub

    Protected Sub dtgEquipoPiezas_ItemInserted(sender As Object, e As Telerik.Web.UI.GridInsertedEventArgs)
        If e.Exception IsNot Nothing Then

            e.ExceptionHandled = True

            SetMessage("La configuracion no pudo ser insertada. Razón: " + e.Exception.Message)

        Else

            SetMessage("La configuracion fue insertada!")

        End If
    End Sub

    Protected Sub dtgEquipoPiezas_PreRender(sender As Object, e As EventArgs)
        If Not String.IsNullOrEmpty(gridMessage) Then

            DisplayMessage(gridMessage)

        End If
    End Sub

    Private Sub dtgEquipoPiezas_DeleteCommand(sender As Object, e As GridCommandEventArgs) Handles dtgEquipoPiezas.DeleteCommand
        Dim editedItem As GridEditableItem = TryCast(e.Item, GridEditableItem)

        Dim codigo As Integer = DirectCast(editedItem.GetDataKeyValue("numero_equipo_piezas"), Integer)

        Using servicio As New Servicios_SIE.Sie_servicesClient
            Dim resultado As String = Convert.ToString(servicio.EliminarEquipoPiezas(codigo))

            If (resultado.Equals("")) Then

                editedItem.Edit = False

                SetMessage("No se puedo eliminar la configuracion")

                dtgEquipoPiezas.DataBind()

            Else

                SetMessage("La configuracion eliminada con éxito")

            End If
        End Using

    End Sub

    Public Sub dtgEquipoPiezas_InsertCommand(sender As Object, e As GridCommandEventArgs) Handles dtgEquipoPiezas.InsertCommand

        Dim editedItem As GridEditableItem = TryCast(e.Item, GridEditableItem)


        Dim Numero_Equipo As RadComboBox = DirectCast(editedItem("Numero_Equipo").Controls(0), RadComboBox)

        Dim Numero_Pieza As RadComboBox = DirectCast(editedItem("Numero_Pieza").Controls(0), RadComboBox)

        Using servicio As New Servicios_SIE.Sie_servicesClient

            'Dim nuevoRegistro As New Servicios_SIE.Categoria With {
            '    .Numero_categoria = 0,
            '    .Categoria = categoria.Text
            '}
            Dim agregarRegistro As New Servicios_SIE.EquipoPiezas
            agregarRegistro.numero_equipo = Numero_Equipo.SelectedValue
            agregarRegistro.numero_pieza = Numero_Pieza.SelectedValue
            agregarRegistro.usuario_creacion = "jorney"
            agregarRegistro.fecha_creacion = Date.Now

            Dim resultado = servicio.InsertarEquipoPiezas(agregarRegistro)
            If resultado.exito Then

            End If

            If (resultado.Equals("")) Then

                SetMessage("No se pudo insertar la configuracion")

                editedItem.Edit = False

                dtgEquipoPiezas.DataBind()

            Else

                SetMessage("La configuracion insertada con éxito")

            End If

        End Using

    End Sub

    Private Sub dtgEquipoPiezas_UpdateCommand(sender As Object, e As GridCommandEventArgs) Handles dtgEquipoPiezas.UpdateCommand

        Dim editedItem As GridEditableItem = TryCast(e.Item, GridEditableItem)

        Dim Numero_Equipo_Pieza As Integer = DirectCast(editedItem.GetDataKeyValue("numero_equipo_piezas"), Integer)

        Dim Numero_Equipo As RadComboBox = DirectCast(editedItem("Numero_Equipo").Controls(0), RadComboBox)

        Dim Numero_Pieza As RadComboBox = DirectCast(editedItem("Numero_Pieza").Controls(0), RadComboBox)



        Using servicio As New Servicios_SIE.Sie_servicesClient

            'Dim modificarRegistro As New Servicios_SIE.Categoria With {
            '    .numero_categoria = Numero_categoria,
            '    .categoria = categoria.Text,
            '    .usuario_modificacion = "Daniel",
            '    .fecha_modificacion = Date.Now
            '}
            Dim modificarRegistro As New Servicios_SIE.EquipoPiezas
            modificarRegistro.numero_equipo_piezas = Numero_Equipo_Pieza
            modificarRegistro.numero_equipo = Numero_Equipo.SelectedValue
            modificarRegistro.numero_pieza = Numero_Pieza.SelectedValue
            modificarRegistro.usuario_modificacion = "Daniel"
            modificarRegistro.fecha_modificacion = Date.Now


            Dim resultado = servicio.ModificarEquipoPiezas(modificarRegistro)
            If resultado.exito Then

            End If

        End Using


    End Sub

End Class