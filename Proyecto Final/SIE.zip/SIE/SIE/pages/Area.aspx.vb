﻿Imports Telerik.Web.UI

Public Class Area

    Inherits System.Web.UI.Page

    Private Sub DisplayMessage(text As String)

        dtgArea.Controls.Add(New LiteralControl(String.Format("<span style='color:red'>{0}</span>", text)))

    End Sub

    Private Sub SetMessage(message As String)

        gridMessage = message

    End Sub

    Private gridMessage As String = Nothing

    Public Function CargarArea() As DataTable

        Using servicio As New Servicios_SIE.Sie_servicesClient

            Dim registros = servicio.ObtenerArea

            Dim data As DataTable = UtilsModule.ConvertToDataTable(registros)

            Return data

        End Using

    End Function
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ScriptManager.RegisterStartupScript(Me, GetType(Page), "alerta", "<script>SetFocusOnTextBox()</script>", False)
    End Sub

    Protected Sub dtgArea_ItemCreated(sender As Object, e As Telerik.Web.UI.GridItemEventArgs)

        If ((TypeOf e.Item Is GridEditFormItem) And e.Item.IsInEditMode) Then

            Dim item As GridEditFormItem = TryCast(e.Item, GridEditFormItem)

            SetFocus(item("Area").Controls(0).ClientID)

        End If
        If TypeOf e.Item Is GridEditableItem AndAlso e.Item.IsInEditMode Then

            If Not (TypeOf e.Item Is GridEditFormInsertItem) Then

                Dim item As GridEditableItem = TryCast(e.Item, GridEditableItem)

                Dim manager As GridEditManager = item.EditManager

                Dim editor As GridTextBoxColumnEditor = TryCast(manager.GetColumnEditor("Numero_area"), GridTextBoxColumnEditor)

                editor.TextBoxControl.Enabled = False

                Dim Area As GridTextBoxColumnEditor = TryCast(manager.GetColumnEditor("Area"), GridTextBoxColumnEditor)


                SetFocus(Area.TextBoxControl.ClientID)




            End If

        End If

    End Sub

    Protected Sub dtgArea_ItemInserted(sender As Object, e As Telerik.Web.UI.GridInsertedEventArgs)
        If e.Exception IsNot Nothing Then

            e.ExceptionHandled = True

            SetMessage("El area no pudo ser insertado. Razón: " + e.Exception.Message)

        Else

            SetMessage("El area fue insertada!")

        End If
    End Sub

    Protected Sub dtgArea_PreRender(sender As Object, e As EventArgs)
        If Not String.IsNullOrEmpty(gridMessage) Then

            DisplayMessage(gridMessage)

        End If
    End Sub

    Private Sub dtgArea_DeleteCommand(sender As Object, e As GridCommandEventArgs) Handles dtgArea.DeleteCommand
        Dim editedItem As GridEditableItem = TryCast(e.Item, GridEditableItem)

        Dim codigo As Integer = DirectCast(editedItem.GetDataKeyValue("Numero_area"), Integer)

        Using servicio As New Servicios_SIE.Sie_servicesClient
            Dim resultado = servicio.EliminarArea(codigo)

            If (resultado.exito = True) Then
                SetMessage("Area eliminada con éxito")

            Else

                editedItem.Edit = False

                SetMessage("No se puedo eliminar el Area")

                dtgArea.DataBind()

            End If
        End Using

    End Sub

    Private Sub dtgArea_InsertCommand(sender As Object, e As GridCommandEventArgs) Handles dtgArea.InsertCommand

        Dim editedItem As GridEditableItem = TryCast(e.Item, GridEditableItem)

        Dim Area As TextBox = DirectCast(editedItem("Area").Controls(0), TextBox)



        Using servicio As New Servicios_SIE.Sie_servicesClient

            'Dim nuevoRegistro As New Servicios_SIE.Categoria With {
            '    .Numero_categoria = 0,
            '    .Categoria = categoria.Text
            '}
            Dim agregarRegistro As New Servicios_SIE.AreaClase
            agregarRegistro.Area = Area.Text
            agregarRegistro.usuario_creacion = User.Identity.Name
            agregarRegistro.fecha_creacion = Date.Now

            Dim resultado = servicio.InsertarArea(agregarRegistro)
            If resultado.exito Then
                SetMessage("El area insertada con éxito")
            Else
                SetMessage("No se pudo insertar el Area")

                editedItem.Edit = False

                dtgArea.DataBind()
            End If


        End Using

    End Sub

    Private Sub dtgArea_UpdateCommand(sender As Object, e As GridCommandEventArgs) Handles dtgArea.UpdateCommand

        Dim editedItem As GridEditableItem = TryCast(e.Item, GridEditableItem)

        Dim Numero_area As Integer = DirectCast(editedItem.GetDataKeyValue("Numero_area"), Integer)

        Dim Area As TextBox = DirectCast(editedItem("Area").Controls(0), TextBox)

        Using servicio As New Servicios_SIE.Sie_servicesClient

            'Dim modificarRegistro As New Servicios_SIE.Categoria With {
            '    .numero_categoria = Numero_categoria,
            '    .categoria = categoria.Text,
            '    .usuario_modificacion = "Daniel",
            '    .fecha_modificacion = Date.Now
            '}
            Dim modificarRegistro As New Servicios_SIE.AreaClase
            modificarRegistro.numero_Area = Numero_area
            modificarRegistro.area = Area.Text
            modificarRegistro.usuario_modificacion = User.Identity.Name
            modificarRegistro.fecha_modificacion = Date.Now


            Dim resultado = servicio.ModificarArea(modificarRegistro)
            If resultado.exito = True Then
                SetMessage("El area actualizada con éxito")
            Else
                SetMessage("No se pudo actuzlizar el Area")

                editedItem.Edit = False

                dtgArea.DataBind()
            End If

        End Using


    End Sub

    Private Sub dtgArea_ItemDataBound(sender As Object, e As GridItemEventArgs) Handles dtgArea.ItemDataBound
        If TypeOf e.Item Is GridEditableItem And e.Item.IsInEditMode Then
            Dim form As GridEditableItem = DirectCast(e.Item, GridEditableItem)
            Dim Area As TextBox = DirectCast(form("Area").Controls(0), TextBox)
            'Area.Attributes.Add("OnFocus", "ActivarFocus(" + Area.ClientID + ")")

        End If
    End Sub
End Class