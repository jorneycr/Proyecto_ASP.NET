﻿Imports Microsoft.VisualBasic

Imports Telerik.Web.UI

Imports System.Linq

Public Class Equipo
    Inherits System.Web.UI.Page

    Private Sub DisplayMessage(text As String)

        dtgEquipo.Controls.Add(New LiteralControl(String.Format("<span style='color:red'>{0}</span>", text)))

    End Sub

    Private Sub SetMessage(message As String)

        gridMessage = message

    End Sub


    Private gridMessage As String = Nothing

    Private Numero_equipo As Integer

    Public Function CargarEquipo() As DataTable

        Using servicio As New Servicios_SIE.Sie_servicesClient

            Dim registros = servicio.ObtenerEquipo

            Dim data As DataTable = UtilsModule.ConvertToDataTable(registros)

            Return data

        End Using

    End Function

    Public Function CargarTiposCategoria() As DataTable
        Using sicarContext As New Servicios_SIE.Sie_servicesClient
            Dim registros = sicarContext.ObtenerCategorias.ToList()
            Dim data As DataTable = UtilsModule.ConvertToDataTable(registros)

            Return data
        End Using
    End Function

    Public Function CargarDepartamento() As List(Of Servicios_SIE.Departamento) 'TipoCarretaService.TipoCarretaDC
        Using sicarContext As New Servicios_SIE.Sie_servicesClient '("BasicHttpBinding_ICategoria") 'TipoCarretaService.TipoCarretaServiceClient("BasicHttpBinding_ITipoCarretaService")
            Dim registros = (From t In sicarContext.ObtenerDepartamento Order By t.departamento Ascending Select t).ToList
            Return registros
        End Using
    End Function

    Public Function CargarArea() As List(Of Servicios_SIE.AreaClase)
        Using sicarContext As New Servicios_SIE.Sie_servicesClient
            Dim registros = (From t In sicarContext.ObtenerArea Order By t.Area Ascending Select t).ToList
            Return registros
        End Using
    End Function

    Public Function CargarBeneficiarios1() As DataTable

        Using sicarContext As New Servicios_SIE.Sie_servicesClient

            Dim registros = sicarContext.ObtenerEmpleado.ToList()

            Dim data As DataTable = UtilsModule.ConvertToDataTable(registros)

            Return data

        End Using

    End Function

    Public Function GetNombreBeneficiario(valor As Object) As String

        GetNombreBeneficiario = ""

        If (Not IsNothing(valor) And Not IsDBNull(valor)) Then

            Try

                Using sicarContext As New Servicios_SIE.Sie_servicesClient

                    GetNombreBeneficiario = sicarContext.ObtenerEmpleadoPorNombre(valor)

                End Using

            Catch ex As Exception

            End Try

        End If

    End Function

    Public Function GetCategoriaBeneficiario(valor As Object) As String

        GetCategoriaBeneficiario = ""

        If (Not IsNothing(valor) And Not IsDBNull(valor)) Then

            Try

                Using sicarContext As New Servicios_SIE.Sie_servicesClient

                    GetCategoriaBeneficiario = sicarContext.ObtenerCategoriaPorNombre(valor)

                End Using

            Catch ex As Exception

            End Try

        End If

    End Function

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Public Sub numero_categoria_SelectedIndexChanged(sender As Object, ByVal e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs)

        Dim list As RadComboBox = CType(sender, RadComboBox)

        Dim editItem As GridEditFormItem = CType(list.NamingContainer, GridEditFormItem)

        Dim cate As RadComboBox = CType(editItem("numero_categoria").Controls(0), RadComboBox)
        'Opciones
        Dim Procesador As TextBox = DirectCast(editItem("Procesador").Controls(0), TextBox)

        Dim RAM As TextBox = DirectCast(editItem("RAM").Controls(0), TextBox)

        Dim disco As TextBox = DirectCast(editItem("disco").Controls(0), TextBox)

        Dim Pantalla As TextBox = DirectCast(editItem("Pantalla").Controls(0), TextBox)

        Dim Puertos As TextBox = DirectCast(editItem("Puertos").Controls(0), TextBox)

        Dim Otros As TextBox = DirectCast(editItem("Otros").Controls(0), TextBox)

        Dim OS As TextBox = DirectCast(editItem("os").Controls(0), TextBox)

        Select Case list.SelectedValue
            Case "Laptops"
                Puertos.Visible = False
                Otros.Visible = False

            Case "Monitor"
                Pantalla.Visible = False

            Case "Tablet"
                Puertos.Visible = False
                Otros.Visible = False

            Case "Celular"
                Puertos.Visible = False
                Otros.Visible = False

            Case "Swicth"
                Pantalla.Visible = False

            Case Else
                '
        End Select
    End Sub

    Protected Sub dtgEquipo_ItemCreated(sender As Object, e As Telerik.Web.UI.GridItemEventArgs)

        If ((TypeOf e.Item Is GridEditFormItem) And e.Item.IsInEditMode) Then


            Dim item As GridEditableItem = e.Item


            SetFocus(item("Service_tag").Controls(0).ClientID)

        End If
        If TypeOf e.Item Is GridEditableItem AndAlso e.Item.IsInEditMode Then

            If Not (TypeOf e.Item Is GridEditFormInsertItem) Then

                Dim item As GridEditableItem = TryCast(e.Item, GridEditableItem)

                Dim manager As GridEditManager = item.EditManager

                Dim editor As GridTextBoxColumnEditor = TryCast(manager.GetColumnEditor("Numero_equipo"), GridTextBoxColumnEditor)

                editor.TextBoxControl.Enabled = False


                Dim Service_tag As GridTextBoxColumnEditor = TryCast(manager.GetColumnEditor("Service_tag"), GridTextBoxColumnEditor)


                SetFocus(Service_tag.TextBoxControl.ClientID)

                Dim Categoria As GridDropDownColumnEditor = TryCast(manager.GetColumnEditor("numero_categoria"), GridDropDownColumnEditor)


                Dim Empleado As GridDropDownColumnEditor = TryCast(manager.GetColumnEditor("numero_empleado"), GridDropDownColumnEditor)

                Dim Departamento As GridDropDownColumnEditor = TryCast(manager.GetColumnEditor("numero_departamento"), GridDropDownColumnEditor)

                Dim Area As GridDropDownColumnEditor = TryCast(manager.GetColumnEditor("numero_area"), GridDropDownColumnEditor)

                Dim Marca As GridTextBoxColumnEditor = TryCast(manager.GetColumnEditor("Marca"), GridTextBoxColumnEditor)

                Dim Modelo As GridTextBoxColumnEditor = TryCast(manager.GetColumnEditor("Modelo"), GridTextBoxColumnEditor)

                Dim Procesador As GridTextBoxColumnEditor = TryCast(manager.GetColumnEditor("Procesador"), GridTextBoxColumnEditor)

                Dim RAM As GridTextBoxColumnEditor = TryCast(manager.GetColumnEditor("RAM"), GridTextBoxColumnEditor)

                Dim disco As GridTextBoxColumnEditor = TryCast(manager.GetColumnEditor("disco"), GridTextBoxColumnEditor)

                Dim Pantalla As GridTextBoxColumnEditor = TryCast(manager.GetColumnEditor("Pantalla"), GridTextBoxColumnEditor)

                Dim Puertos As GridTextBoxColumnEditor = TryCast(manager.GetColumnEditor("Puertos"), GridTextBoxColumnEditor)

                Dim Otros As GridTextBoxColumnEditor = TryCast(manager.GetColumnEditor("Otros"), GridTextBoxColumnEditor)

                Dim Tipo As GridTextBoxColumnEditor = TryCast(manager.GetColumnEditor("Tipo"), GridTextBoxColumnEditor)

                Dim Descripcion As GridTextBoxColumnEditor = TryCast(manager.GetColumnEditor("Descripcion"), GridTextBoxColumnEditor)





            End If

        End If


    End Sub

    Protected Sub dtgEquipo_ItemInserted(sender As Object, e As Telerik.Web.UI.GridInsertedEventArgs)
        If e.Exception IsNot Nothing Then

            e.ExceptionHandled = True

            SetMessage("El equipo no pudo ser insertado. Razón: " + e.Exception.Message)

        Else

            SetMessage("El equipo fue insertado!")

        End If
    End Sub

    Protected Sub dtgEquipo_PreRender(sender As Object, e As EventArgs)
        If Not String.IsNullOrEmpty(gridMessage) Then

            DisplayMessage(gridMessage)

        End If

    End Sub

    Protected Sub Page_PreRender(sender As Object, e As EventArgs)


    End Sub

    Private Sub dtgEquipo_DeleteCommand(sender As Object, e As GridCommandEventArgs) Handles dtgEquipo.DeleteCommand
        Dim editedItem As GridEditableItem = TryCast(e.Item, GridEditableItem)

        Dim codigo As Integer = DirectCast(editedItem.GetDataKeyValue("Numero_equipo"), Integer)

        Using servicio As New Servicios_SIE.Sie_servicesClient
            Dim resultado = servicio.EliminarEquipo(codigo)

            If (resultado.exito = True) Then
                SetMessage("Equipo eliminada con éxito")


            Else

                editedItem.Edit = False

                SetMessage("No se puedo eliminar el equipo")

                dtgEquipo.DataBind()

            End If
        End Using

    End Sub

    Public Sub dtgEquipo_InsertCommand(sender As Object, e As GridCommandEventArgs) Handles dtgEquipo.InsertCommand

        Dim editedItem As GridEditableItem = TryCast(e.Item, GridEditableItem)

        'Dim Categoria As RadComboBox = DirectCast(editedItem("numero_categoria").Controls(0), RadComboBox)
        'DirectCast(e.Item, GridEditableItem)
        Dim Categoria As RadComboBox = DirectCast(editedItem("numero_categoria").FindControl("Categoria1"), RadComboBox)
        'Dim Empleado As RadComboBox = DirectCast(editedItem("numero_empleado").Controls(0), RadComboBox)
        Dim Empleado As RadComboBox = DirectCast(editedItem("numero_empleado").FindControl("EMPLEADO1"), RadComboBox)

        'Dim Departamento As RadComboBox = DirectCast(editedItem("numero_departamento").FindControl("DEPARTAMENTO1"), RadComboBox)
        Dim Departamento As RadComboBox = DirectCast(editedItem("numero_departamento").Controls(0), RadComboBox)

        Dim Area As RadComboBox = DirectCast(editedItem("numero_area").Controls(0), RadComboBox)

        Dim Service_tag As TextBox = DirectCast(editedItem("Service_tag").Controls(0), TextBox)

        Dim Marca As TextBox = DirectCast(editedItem("Marca").Controls(0), TextBox)

        Dim Modelo As TextBox = DirectCast(editedItem("Modelo").Controls(0), TextBox)

        Dim Tipo As TextBox = DirectCast(editedItem("Tipo").Controls(0), TextBox)

        Dim Descripcion As TextBox = DirectCast(editedItem("Descripcion").Controls(0), TextBox)

        Dim Procesador As TextBox = DirectCast(editedItem("Procesador").Controls(0), TextBox)

        Dim RAM As TextBox = DirectCast(editedItem("RAM").Controls(0), TextBox)

        Dim disco As TextBox = DirectCast(editedItem("disco").Controls(0), TextBox)

        Dim Pantalla As TextBox = DirectCast(editedItem("Pantalla").Controls(0), TextBox)

        Dim Puertos As TextBox = DirectCast(editedItem("Puertos").Controls(0), TextBox)

        Dim Otros As TextBox = DirectCast(editedItem("Otros").Controls(0), TextBox)


        Dim OS As TextBox = DirectCast(editedItem("os").Controls(0), TextBox)


        Using servicio As New Servicios_SIE.Sie_servicesClient



            'Dim nuevoRegistro As New Servicios_SIE.Categoria With {
            '    .Numero_categoria = 0,
            '    .Categoria = categoria.Text
            '}
            Dim agregarRegistro As New Servicios_SIE.Equipo
            agregarRegistro.numero_categoria = Categoria.SelectedValue
            agregarRegistro.numero_empleado = Empleado.SelectedValue
            agregarRegistro.numero_departamento = Departamento.SelectedValue
            agregarRegistro.numero_area = Area.SelectedValue
            agregarRegistro.service_tag = Service_tag.Text
            agregarRegistro.marca = Marca.Text
            agregarRegistro.modelo = Modelo.Text
            agregarRegistro.tipo = Tipo.Text
            agregarRegistro.procesador = Procesador.Text
            agregarRegistro.ram = RAM.Text
            agregarRegistro.disco = disco.Text
            agregarRegistro.pantalla = Pantalla.Text
            agregarRegistro.puertos = Puertos.Text
            agregarRegistro.otros = Otros.Text
            agregarRegistro.os = OS.Text
            agregarRegistro.descripcion = Descripcion.Text
            agregarRegistro.usuario_creacion = User.Identity.Name
            agregarRegistro.fecha_creacion = Date.Now

            Dim resultado = servicio.InsertarEquipo(agregarRegistro)



            'Fin Historial

            If resultado.exito = True Then
                SetMessage("El equipo insertada con éxito")

                'Agregar el historial

                Dim agregarHistorial As New Servicios_SIE.Historial
                Dim sicarContext As New Servicios_SIE.Sie_servicesClient '("BasicHttpBinding_ICategoria") 'TipoCarretaService.TipoCarretaServiceClient("BasicHttpBinding_ITipoCarretaService")

                Dim numero_equipos As Integer = sicarContext.obtenerNumero(Service_tag.Text)
                agregarHistorial.numero_equipo = numero_equipos
                agregarHistorial.numero_categoria = Categoria.SelectedValue
                agregarHistorial.numero_empleado = Empleado.SelectedValue
                agregarHistorial.numero_departamento = Departamento.SelectedValue
                agregarHistorial.numero_area = Area.SelectedValue
                agregarHistorial.service_tag = Service_tag.Text
                agregarHistorial.marca = Marca.Text
                agregarHistorial.modelo = Modelo.Text
                agregarHistorial.procesador = Procesador.Text
                agregarHistorial.ram = RAM.Text
                agregarHistorial.disco = disco.Text
                agregarHistorial.pantalla = Pantalla.Text
                agregarHistorial.puertos = Puertos.Text
                agregarHistorial.otros = Otros.Text
                agregarHistorial.tipo = Tipo.Text
                agregarHistorial.descripcion = Descripcion.Text
                agregarHistorial.os = OS.Text
                agregarHistorial.usuario_creacion = User.Identity.Name
                agregarHistorial.fecha_creacion = Date.Now

                servicio.InsertarEquipoHistorial(agregarHistorial)

            Else
                SetMessage("No se pudo insertar el equipo")

                editedItem.Edit = False

                dtgEquipo.DataBind()
            End If



        End Using

    End Sub

    Public Sub dtgEquipo_UpdateCommand(sender As Object, e As GridCommandEventArgs) Handles dtgEquipo.UpdateCommand

        Dim editedItem As GridEditableItem = TryCast(e.Item, GridEditableItem)

        Dim Numero_equipo As Integer = DirectCast(editedItem.GetDataKeyValue("Numero_equipo"), Integer)

        Dim Service_tag As TextBox = DirectCast(editedItem("Service_tag").Controls(0), TextBox)

        Dim Marca As TextBox = DirectCast(editedItem("Marca").Controls(0), TextBox)

        Dim Modelo As TextBox = DirectCast(editedItem("Modelo").Controls(0), TextBox)

        Dim Tipo As TextBox = DirectCast(editedItem("Tipo").Controls(0), TextBox)

        Dim Procesador As TextBox = DirectCast(editedItem("Procesador").Controls(0), TextBox)

        Dim RAM As TextBox = DirectCast(editedItem("RAM").Controls(0), TextBox)

        Dim disco As TextBox = DirectCast(editedItem("disco").Controls(0), TextBox)

        Dim Pantalla As TextBox = DirectCast(editedItem("Pantalla").Controls(0), TextBox)

        Dim Puertos As TextBox = DirectCast(editedItem("Puertos").Controls(0), TextBox)

        Dim Otros As TextBox = DirectCast(editedItem("Otros").Controls(0), TextBox)


        Dim Descripcion As TextBox = DirectCast(editedItem("Descripcion").Controls(0), TextBox)

        Dim OS As TextBox = DirectCast(editedItem("os").Controls(0), TextBox)

        Dim Categoria As RadComboBox = DirectCast(editedItem("numero_categoria").FindControl("Categoria1"), RadComboBox)

        Dim Empleado As RadComboBox = DirectCast(editedItem("numero_empleado").FindControl("EMPLEADO1"), RadComboBox)

        Dim Departamento As RadComboBox = DirectCast(editedItem("numero_departamento").Controls(0), RadComboBox)

        Dim Area As RadComboBox = DirectCast(editedItem("numero_area").Controls(0), RadComboBox)



        'Dim Departamento As RadComboBox = DirectCast(editedItem("numero_departamento").FindControl("DEPARTAMENTO1"), RadComboBox)


        'Dim Empleado As RadComboBox = DirectCast(editedItem("numero_empleado").Controls(0), RadComboBox)



        Using servicio As New Servicios_SIE.Sie_servicesClient

            'Dim modificarRegistro As New Servicios_SIE.Categoria With {
            '    .numero_categoria = Numero_categoria,
            '    .categoria = categoria.Text,
            '    .usuario_modificacion = "Daniel",
            '    .fecha_modificacion = Date.Now
            '}
            Dim modificarRegistro As New Servicios_SIE.Equipo
            modificarRegistro.numero_equipo = Numero_equipo
            modificarRegistro.service_tag = Service_tag.Text
            modificarRegistro.numero_categoria = Categoria.SelectedValue
            modificarRegistro.numero_empleado = Empleado.SelectedValue
            modificarRegistro.numero_departamento = Departamento.SelectedValue
            modificarRegistro.numero_area = Area.SelectedValue
            modificarRegistro.marca = Marca.Text
            modificarRegistro.modelo = Modelo.Text
            modificarRegistro.tipo = Tipo.Text
            modificarRegistro.descripcion = Descripcion.Text
            modificarRegistro.procesador = Procesador.Text
            modificarRegistro.ram = RAM.Text
            modificarRegistro.disco = disco.Text
            modificarRegistro.pantalla = Pantalla.Text
            modificarRegistro.puertos = Puertos.Text
            modificarRegistro.otros = Otros.Text
            modificarRegistro.os = OS.Text
            modificarRegistro.usuario_modificacion = User.Identity.Name
            modificarRegistro.fecha_modificacion = Date.Now


            Dim resultado = servicio.ModificarEquipo(modificarRegistro)



            If resultado.exito = True Then
                SetMessage("El equipo insertada con éxito")

                'Insertar Historial
                Dim agregarHistorial As New Servicios_SIE.Historial
                agregarHistorial.numero_equipo = Numero_equipo
                agregarHistorial.service_tag = Service_tag.Text
                agregarHistorial.marca = Marca.Text
                agregarHistorial.modelo = Modelo.Text
                agregarHistorial.tipo = Tipo.Text
                agregarHistorial.descripcion = Descripcion.Text
                agregarHistorial.procesador = Procesador.Text
                agregarHistorial.ram = RAM.Text
                agregarHistorial.disco = disco.Text
                agregarHistorial.pantalla = Pantalla.Text
                agregarHistorial.puertos = Puertos.Text
                agregarHistorial.otros = Otros.Text
                agregarHistorial.os = OS.Text
                agregarHistorial.numero_categoria = Categoria.SelectedValue
                agregarHistorial.numero_empleado = Empleado.SelectedValue
                agregarHistorial.numero_departamento = Departamento.SelectedValue
                agregarHistorial.numero_area = Area.SelectedValue
                agregarHistorial.usuario_modificacion = User.Identity.Name
                agregarHistorial.fecha_modificacion = Date.Now


                servicio.InsertarEquipoHistorial(agregarHistorial)
                'Fin Historial

            Else
                SetMessage("No se pudo actualizar el equipo")

                editedItem.Edit = False

                dtgEquipo.DataBind()
            End If

        End Using


    End Sub

    Protected Sub dtgEquipo_ItemDataBound(sender As Object, e As GridItemEventArgs)
        If e.Item.IsInEditMode Then

            Dim item As GridEditableItem = DirectCast(e.Item, GridEditableItem)

            'Dim list As RadComboBox = CType(sender, RadComboBox)
            'Dim editItem1 As GridEditFormItem = CType(list.NamingContainer, GridEditFormItem)




            If TypeOf e.Item Is GridEditableItem And e.Item.IsInEditMode Then
                Dim form As GridEditableItem = DirectCast(e.Item, GridEditableItem)
                Dim Service_tag As TextBox = DirectCast(form("Service_tag").Controls(0), TextBox)
                Dim Marca As TextBox = DirectCast(form("Marca").Controls(0), TextBox)
                Dim Modelo As TextBox = DirectCast(form("Modelo").Controls(0), TextBox)
                Dim Procesador As TextBox = DirectCast(form("Procesador").Controls(0), TextBox)
                Dim disco As TextBox = DirectCast(form("disco").Controls(0), TextBox)
                Dim Puertos As TextBox = DirectCast(form("Puertos").Controls(0), TextBox)
                Dim Pantalla As TextBox = DirectCast(form("Pantalla").Controls(0), TextBox)
                Dim RAM As TextBox = DirectCast(form("RAM").Controls(0), TextBox)
                Dim OS As TextBox = DirectCast(form("os").Controls(0), TextBox)
                Dim Otros As TextBox = DirectCast(form("Otros").Controls(0), TextBox)
                Dim Estado As TextBox = DirectCast(form("Tipo").Controls(0), TextBox)
                Dim Descripcion As TextBox = DirectCast(form("Descripcion").Controls(0), TextBox)



                Service_tag.Attributes.Add("focus", Service_tag.ClientID)


            End If

            If Not (TypeOf e.Item Is IGridInsertItem) Then

                Dim EMPLEADO1 As RadComboBox = DirectCast(item.FindControl("EMPLEADO1"), RadComboBox)

                Dim Categoria1 As RadComboBox = DirectCast(item.FindControl("Categoria1"), RadComboBox)

                EMPLEADO1.Width = Unit.Pixel(350)

                Categoria1.Width = Unit.Pixel(350)

                'Dim cboCategoria As RadComboBox = DirectCast(item.FindControl("numero_categoria"), RadComboBox)

                'cboCategoria.AutoPostBack = True

                'cboCategoria.SelectedIndex

                'Dim DEPARTAMENTO1 As RadComboBox = DirectCast(item.FindControl("DEPARTAMENTO1"), RadComboBox)

                'DEPARTAMENTO1.Width = Unit.Pixel(350)


                Dim selectedItem As New RadComboBoxItem()

                Dim editItem As GridEditableItem = CType(e.Item, GridEditableItem)

                Dim dataRow As DataRowView = DirectCast(e.Item.DataItem, DataRowView)

                Dim numero_empleado As String = dataRow("numero_empleado").ToString()

                Dim numero_categoria As String = dataRow("numero_categoria").ToString()

                'Dim numero_departamento As String = dataRow("numero_departamento").ToString()

                If (Not numero_empleado.Equals(String.Empty)) Then

                    Using sicarContext As New Servicios_SIE.Sie_servicesClient 'PropietarioService.PropietarioServiceClient("BasicHttpBinding_IPropietarioService")

                        Dim objeto = sicarContext.ObtenerEmpleadoPorParametro(numero_empleado)

                        If Not IsNothing(objeto) Then

                            'selectedItem.Text = objeto.empleado

                            selectedItem.Value = numero_empleado

                            EMPLEADO1.Items.Add(selectedItem)

                            selectedItem.DataBind()

                            Session("numero_empleado") = selectedItem.Value

                        End If
                    End Using

                End If

                If (Not numero_categoria.Equals(String.Empty)) Then

                    Using sicarContext As New Servicios_SIE.Sie_servicesClient 'PropietarioService.PropietarioServiceClient("BasicHttpBinding_IPropietarioService")

                        Dim objeto = sicarContext.ObtenerCategoriaPorParametro(numero_categoria)

                        If Not IsNothing(objeto) Then

                            'selectedItem.Text = objeto.departamento

                            selectedItem.Value = numero_categoria

                            Categoria1.Items.Add(selectedItem)

                            selectedItem.DataBind()

                            Session("numero_empleado") = selectedItem.Value

                        End If
                    End Using

                End If

            End If
        End If
    End Sub

    Public Function Categoria1_SelectedIndexChanged(sender As Object, e As RadComboBoxSelectedIndexChangedEventArgs)

        Dim list As RadComboBox = CType(sender, RadComboBox)
        Dim editItem As GridEditFormItem = CType(list.NamingContainer, GridEditFormItem)

        Dim value As String = list.Text

        For Each item As GridDataItem In dtgEquipo.EditItems
            Dim edititems As GridEditableItem = CType(item.EditFormItem, GridEditableItem)
            Dim Service_tag As TextBox = DirectCast(editItem("Service_tag").Controls(0), TextBox)
            Dim Marca As TextBox = DirectCast(editItem("Marca").Controls(0), TextBox)
            Dim Modelo As TextBox = DirectCast(editItem("Modelo").Controls(0), TextBox)
            Dim Otros As TextBox = DirectCast(editItem("Otros").Controls(0), TextBox)
            Dim Procesador As TextBox = DirectCast(editItem("Procesador").Controls(0), TextBox)
            Dim disco As TextBox = DirectCast(editItem("disco").Controls(0), TextBox)
            Dim Puertos As TextBox = DirectCast(editItem("Puertos").Controls(0), TextBox)
            Dim Pantalla As TextBox = DirectCast(editItem("Pantalla").Controls(0), TextBox)
            Dim RAM As TextBox = DirectCast(editItem("RAM").Controls(0), TextBox)
            Dim OS As TextBox = DirectCast(editItem("os").Controls(0), TextBox)
            Dim Estado As TextBox = DirectCast(editItem("Tipo").Controls(0), TextBox)
            Dim Descripcion As TextBox = DirectCast(editItem("Descripcion").Controls(0), TextBox)
            'If Otros Is Nothing Then
            If value = "Celular" Or value = "Computadora" Or value = "Tablet" Then

                Otros.Visible = False
                Puertos.Visible = False
                OS.Visible = True
                Pantalla.Visible = False
                Procesador.Visible = True
                RAM.Visible = True
                disco.Visible = True
                Service_tag.Attributes.Add("onkeydown", "return Siguiente('" & Marca.ClientID & "');")
                Marca.Attributes.Add("onkeydown", "return Siguiente('" & Modelo.ClientID & "');")
                Modelo.Attributes.Add("onkeydown", "return Siguiente('" & Procesador.ClientID & "');")
                Procesador.Attributes.Add("onkeydown", "return Siguiente('" & RAM.ClientID & "');")
                RAM.Attributes.Add("onkeydown", "return Siguiente('" & disco.ClientID & "');")
                disco.Attributes.Add("onkeydown", "return Siguiente('" & Pantalla.ClientID & "');")
                Pantalla.Attributes.Add("onkeydown", "return Siguiente('" & OS.ClientID & "');")
                OS.Attributes.Add("onkeydown", "return Siguiente('" & Estado.ClientID & "');")
                Estado.Attributes.Add("onkeydown", "return Siguiente('" & Descripcion.ClientID & "');")

            ElseIf value = "Swicth" Then
                Pantalla.Visible = False
                Procesador.Visible = False
                RAM.Visible = False
                disco.Visible = False
                Otros.Visible = True
                Puertos.Visible = True
                OS.Visible = False
                Service_tag.Attributes.Add("onkeydown", "return Siguiente('" & Marca.ClientID & "');")
                Marca.Attributes.Add("onkeydown", "return Siguiente('" & Modelo.ClientID & "');")
                Modelo.Attributes.Add("onkeydown", "return Siguiente('" & Puertos.ClientID & "');")
                Puertos.Attributes.Add("onkeydown", "return Siguiente('" & Otros.ClientID & "');")
                Otros.Attributes.Add("onkeydown", "return Siguiente('" & Estado.ClientID & "');")
                Estado.Attributes.Add("onkeydown", "return Siguiente('" & Descripcion.ClientID & "');")
            ElseIf value = "Monitor" Then
                Pantalla.Visible = True
                Procesador.Visible = False
                RAM.Visible = False
                disco.Visible = False
                Otros.Visible = False
                Puertos.Visible = True
                OS.Visible = False
                Service_tag.Attributes.Add("onkeydown", "return Siguiente('" & Marca.ClientID & "');")
                Marca.Attributes.Add("onkeydown", "return Siguiente('" & Modelo.ClientID & "');")
                Modelo.Attributes.Add("onkeydown", "return Siguiente('" & Pantalla.ClientID & "');")
                Pantalla.Attributes.Add("onkeydown", "return Siguiente('" & Estado.ClientID & "');")
                Estado.Attributes.Add("onkeydown", "return Siguiente('" & Descripcion.ClientID & "');")
            ElseIf value = "UPS" Or value = "Radio" Or value = "Telefono IP" Then
                Pantalla.Visible = False
                Procesador.Visible = False
                RAM.Visible = False
                disco.Visible = False
                Otros.Visible = False
                Puertos.Visible = False
                OS.Visible = False
                Service_tag.Attributes.Add("onkeydown", "return Siguiente('" & Marca.ClientID & "');")
                Marca.Attributes.Add("onkeydown", "return Siguiente('" & Modelo.ClientID & "');")
                Modelo.Attributes.Add("onkeydown", "return Siguiente('" & Estado.ClientID & "');")
                Estado.Attributes.Add("onkeydown", "return Siguiente('" & Descripcion.ClientID & "');")

            End If
            'End If
        Next

        If dtgEquipo.MasterTableView.IsItemInserted Then
            Dim insert As GridEditableItem = CType(dtgEquipo.MasterTableView.GetInsertItem(), GridEditableItem)
            Dim Otros As TextBox = DirectCast(editItem("Otros").Controls(0), TextBox)
            Dim Service_tag As TextBox = DirectCast(editItem("Service_tag").Controls(0), TextBox)
            Dim Marca As TextBox = DirectCast(editItem("Marca").Controls(0), TextBox)
            Dim Modelo As TextBox = DirectCast(editItem("Modelo").Controls(0), TextBox)
            Dim Procesador As TextBox = DirectCast(editItem("Procesador").Controls(0), TextBox)
            Dim disco As TextBox = DirectCast(editItem("disco").Controls(0), TextBox)
            Dim Puertos As TextBox = DirectCast(editItem("Puertos").Controls(0), TextBox)
            Dim Pantalla As TextBox = DirectCast(editItem("Pantalla").Controls(0), TextBox)
            Dim RAM As TextBox = DirectCast(editItem("RAM").Controls(0), TextBox)
            Dim OS As TextBox = DirectCast(editItem("os").Controls(0), TextBox)
            Dim Estado As TextBox = DirectCast(editItem("Tipo").Controls(0), TextBox)
            Dim Descripcion As TextBox = DirectCast(editItem("Descripcion").Controls(0), TextBox)
            'Dim OtrosLa As Label = DirectCast(editItem("Otros").Controls(0), Label)
            'If Otros Is Nothing Then
            If value = "Celular" Or value = "Computadora" Or value = "Tablet" Then
                Service_tag.Attributes.Add("onkeydown", "return Siguiente('" & Marca.ClientID & "');")
                Marca.Attributes.Add("onkeydown", "return Siguiente('" & Modelo.ClientID & "');")
                Otros.Visible = False
                Puertos.Visible = False
                OS.Visible = True
                Pantalla.Visible = True
                Procesador.Visible = True
                RAM.Visible = True
                disco.Visible = True
                Service_tag.Attributes.Add("onkeydown", "return Siguiente('" & Marca.ClientID & "');")
                Marca.Attributes.Add("onkeydown", "return Siguiente('" & Modelo.ClientID & "');")
                Modelo.Attributes.Add("onkeydown", "return Siguiente('" & Procesador.ClientID & "');")
                Procesador.Attributes.Add("onkeydown", "return Siguiente('" & RAM.ClientID & "');")
                RAM.Attributes.Add("onkeydown", "return Siguiente('" & disco.ClientID & "');")
                disco.Attributes.Add("onkeydown", "return Siguiente('" & Pantalla.ClientID & "');")
                Pantalla.Attributes.Add("onkeydown", "return Siguiente('" & OS.ClientID & "');")
                OS.Attributes.Add("onkeydown", "return Siguiente('" & Estado.ClientID & "');")
                Estado.Attributes.Add("onkeydown", "return Siguiente('" & Descripcion.ClientID & "');")

            ElseIf value = "Swicth" Then
                Pantalla.Visible = False
                Procesador.Visible = False
                RAM.Visible = False
                disco.Visible = False
                Otros.Visible = True
                Puertos.Visible = True
                OS.Visible = False
                Service_tag.Attributes.Add("onkeydown", "return Siguiente('" & Marca.ClientID & "');")
                Marca.Attributes.Add("onkeydown", "return Siguiente('" & Modelo.ClientID & "');")
                Modelo.Attributes.Add("onkeydown", "return Siguiente('" & Puertos.ClientID & "');")
                Puertos.Attributes.Add("onkeydown", "return Siguiente('" & Otros.ClientID & "');")
                Otros.Attributes.Add("onkeydown", "return Siguiente('" & Estado.ClientID & "');")
                Estado.Attributes.Add("onkeydown", "return Siguiente('" & Descripcion.ClientID & "');")
            ElseIf value = "Monitor" Then
                Pantalla.Visible = True
                Procesador.Visible = False
                RAM.Visible = False
                disco.Visible = False
                Otros.Visible = False
                Puertos.Visible = False
                OS.Visible = False
                Service_tag.Attributes.Add("onkeydown", "return Siguiente('" & Marca.ClientID & "');")
                Marca.Attributes.Add("onkeydown", "return Siguiente('" & Modelo.ClientID & "');")
                Modelo.Attributes.Add("onkeydown", "return Siguiente('" & Pantalla.ClientID & "');")
                Pantalla.Attributes.Add("onkeydown", "return Siguiente('" & Estado.ClientID & "');")
                Estado.Attributes.Add("onkeydown", "return Siguiente('" & Descripcion.ClientID & "');")
            ElseIf value = "UPS" Or value = "Radio" Or value = "Telefono IP" Then
                Pantalla.Visible = False
                Procesador.Visible = False
                RAM.Visible = False
                disco.Visible = False
                Otros.Visible = False
                Puertos.Visible = False
                OS.Visible = False
                Service_tag.Attributes.Add("onkeydown", "return Siguiente('" & Marca.ClientID & "');")
                Marca.Attributes.Add("onkeydown", "return Siguiente('" & Modelo.ClientID & "');")
                Modelo.Attributes.Add("onkeydown", "return Siguiente('" & Estado.ClientID & "');")
                Estado.Attributes.Add("onkeydown", "return Siguiente('" & Descripcion.ClientID & "');")

            End If

        End If
        Return list

    End Function

End Class