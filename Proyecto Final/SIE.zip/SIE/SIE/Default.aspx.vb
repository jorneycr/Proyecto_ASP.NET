﻿Imports SIE

Public Class _Default
    Inherits Page



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        errores.Text = ""
        If User.Identity.Name = "" Then
            Response.Redirect("~/seguridad/Login")
        End If
        If (Not IsPostBack) Then

            'Dim site As MasterPage = CType(Page.Master, Externa)

            Dim param As String = Request.Params("errorCode")

            If (Not IsNothing(param)) Then

                If (param.Equals("401")) Then

                    errores.Text = "No está autorizado para utilizar la página solicitada."

                End If



            End If

        End If

    End Sub
End Class


