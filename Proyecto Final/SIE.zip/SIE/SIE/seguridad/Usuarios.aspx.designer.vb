﻿'------------------------------------------------------------------------------
' <generado automáticamente>
'     Este código fue generado por una herramienta.
'
'     Los cambios en este archivo podrían causar un comportamiento incorrecto y se perderán si
'     se vuelve a generar el código. 
' </generado automáticamente>
'------------------------------------------------------------------------------

Option Strict On
Option Explicit On


Partial Public Class Usuarios
    
    '''<summary>
    '''Control RegisterHyperLink.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents RegisterHyperLink As Global.System.Web.UI.WebControls.HyperLink
    
    '''<summary>
    '''Control TabPrincipal.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents TabPrincipal As Global.Telerik.Web.UI.RadTabStrip
    
    '''<summary>
    '''Control UsuariosMultiPageView.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents UsuariosMultiPageView As Global.Telerik.Web.UI.RadMultiPage
    
    '''<summary>
    '''Control registradosPageView.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents registradosPageView As Global.Telerik.Web.UI.RadPageView
    
    '''<summary>
    '''Control resetFilters.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents resetFilters As Global.System.Web.UI.WebControls.HyperLink
    
    '''<summary>
    '''Control UserAccountsGV.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents UserAccountsGV As Global.Telerik.Web.UI.RadGrid
    
    '''<summary>
    '''Control UsuariosDataSource.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents UsuariosDataSource As Global.System.Web.UI.WebControls.ObjectDataSource
    
    '''<summary>
    '''Control permisosUsuarioPageView.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents permisosUsuarioPageView As Global.Telerik.Web.UI.RadPageView
    
    '''<summary>
    '''Control upL.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents upL As Global.System.Web.UI.UpdatePanel
    
    '''<summary>
    '''Control ActionStatus.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents ActionStatus As Global.System.Web.UI.WebControls.Label
    
    '''<summary>
    '''Control UserList.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents UserList As Global.System.Web.UI.WebControls.DropDownList
    
    '''<summary>
    '''Control unblockUser.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents unblockUser As Global.System.Web.UI.WebControls.Button
    
    '''<summary>
    '''Control asignarTodos.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents asignarTodos As Global.System.Web.UI.WebControls.Button
    
    '''<summary>
    '''Control eliminarTodos.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents eliminarTodos As Global.System.Web.UI.WebControls.Button
    
    '''<summary>
    '''Control UsersRoleList.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents UsersRoleList As Global.System.Web.UI.WebControls.Repeater
    
    '''<summary>
    '''Control usuarioPermisoPageView.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents usuarioPermisoPageView As Global.Telerik.Web.UI.RadPageView
    
    '''<summary>
    '''Control upP.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents upP As Global.System.Web.UI.UpdatePanel
    
    '''<summary>
    '''Control ActionStatus2.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents ActionStatus2 As Global.System.Web.UI.WebControls.Label
    
    '''<summary>
    '''Control RoleList.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents RoleList As Global.System.Web.UI.WebControls.DropDownList
    
    '''<summary>
    '''Control RolesUserList.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents RolesUserList As Global.System.Web.UI.WebControls.GridView
    
    '''<summary>
    '''Control UserNameToAddToRole.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents UserNameToAddToRole As Global.System.Web.UI.WebControls.TextBox
    
    '''<summary>
    '''Control AddUserToRoleButton.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents AddUserToRoleButton As Global.System.Web.UI.WebControls.Button
End Class
