﻿Public Class Cambiar
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If (Not IsPostBack) Then

            'Dim param = Request.Params("UserName")
            'If (Not IsNothing(param)) Then
            '    ChangeUserPassword.UserName = param
            'End If

            'Dim paramError = Request.Params("ExpiredDays")

            'If (Not IsNothing(param)) Then
            '    errorPagina.Text = "Su contraseña tiene " & paramError & " día(s) de vencido"
            'End If

            ChangeUserPassword.UserName = User.Identity.Name
            Dim txtCurrPass As TextBox = CType(ChangeUserPassword.ChangePasswordTemplateContainer.FindControl("CurrentPassword"), TextBox)
            txtCurrPass.Focus()

        End If

    End Sub

    Private Sub ChangePassword_PreRender(sender As Object, e As EventArgs) Handles Me.PreRender

        Dim txtUser As TextBox = CType(ChangeUserPassword.ChangePasswordTemplateContainer.FindControl("UserName"), TextBox)

        Dim txtCurrPass As TextBox = CType(ChangeUserPassword.ChangePasswordTemplateContainer.FindControl("CurrentPassword"), TextBox)

        Dim txtNewPass As TextBox = CType(ChangeUserPassword.ChangePasswordTemplateContainer.FindControl("NewPassword"), TextBox)

        Dim txtConfNewPass As TextBox = CType(ChangeUserPassword.ChangePasswordTemplateContainer.FindControl("ConfirmNewPassword"), TextBox)

        Dim btn As Button = CType(ChangeUserPassword.ChangePasswordTemplateContainer.FindControl("CancelPushButton"), Button)

        txtCurrPass.Focus()

        txtUser.Attributes.Add("onkeydown", "return mis_datos(this,false,'" + txtCurrPass.ClientID + "',1);")

        txtCurrPass.Attributes.Add("onkeydown", "return siguiente(this,'" + txtNewPass.ClientID + "',1);")

        txtNewPass.Attributes.Add("onkeydown", "return siguiente(this,'" + txtConfNewPass.ClientID + "',1);")

        txtConfNewPass.Attributes.Add("onkeydown", "return siguiente(this,'" + btn.ClientID + "',1);")

    End Sub

End Class