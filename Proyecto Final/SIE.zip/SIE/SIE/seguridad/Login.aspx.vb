﻿Public Class Login
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If (Not IsPostBack) Then
            If (Request.IsAuthenticated And Not String.IsNullOrEmpty(Request.QueryString("ReturnUrl"))) Then
                Response.Redirect("~/Default.aspx?errorCode=401")
            End If
            Dim us As TextBox = CType(LoginUser.FindControl("UserName"), TextBox)
            us.Focus()
        End If
    End Sub

    Private Sub LoginUser_LoginError(sender As Object, e As EventArgs) Handles LoginUser.LoginError
        LoginUser.FailureText = "El usuario o clave estan incorrectos!!!"
    End Sub

    'Private Sub LoginUser_Authenticate(sender As Object, e As AuthenticateEventArgs) Handles LoginUser.Authenticate
    '    If Membership.ValidateUser(LoginUser.UserName, LoginUser.Password) Then
    '        e.Authenticated = True
    '        Response.Redirect("~/Default.aspx")
    '    Else
    '        e.Authenticated = False
    '    End If
    'End Sub


End Class