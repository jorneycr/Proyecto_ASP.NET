﻿Public Class Usuarios
    Inherits System.Web.UI.Page
    Public Function CargarUsuarios() As DataTable
        Dim mc As MembershipUserCollection = Membership.FindUsersByName(Me.UsernameToMatch & "%")
        Dim lista As New List(Of MembershipUser)
        For Each m As MembershipUser In mc
            lista.Add(m)
        Next
        Dim data As DataTable = UtilsModule.ConvertToDataTable(lista)
        Return data
    End Function


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ActionStatus.Text = ""
        ActionStatus2.Text = ""
        RegisterHyperLink.NavigateUrl = "Register.aspx?ReturnUrl=" + HttpUtility.UrlEncode(Request.QueryString("ReturnUrl"))
        If (Not IsPostBack) Then
            BindUsersToUserList()
            BindRolesToList()
            CheckRolesForSelectedUser()
            DisplayUsersBelongingToRole()
        End If
    End Sub



    Private Sub BindUsersToUserList()
        Dim users As MembershipUserCollection = Membership.GetAllUsers
        UserList.DataSource = users
        UserList.DataBind()
    End Sub

    Private Sub BindRolesToList()
        Dim rols As String() = Roles.GetAllRoles
        UsersRoleList.DataSource = rols.Where(Function(p) p.StartsWith("Sie"))
        UsersRoleList.DataBind()
        RoleList.DataSource = rols.Where(Function(p) p.StartsWith("Sie"))
        RoleList.DataBind()
    End Sub

    Private Sub CheckRolesForSelectedUser()
        Dim selectedUserName As String = UserList.SelectedValue
        Dim u As MembershipUser = Membership.GetUser(selectedUserName)
        If (u.IsLockedOut) Then
            unblockUser.Enabled = True
        Else
            unblockUser.Enabled = False
        End If

        Dim selectedUsersRoles As String() = Roles.GetRolesForUser(selectedUserName)

        For Each ri As RepeaterItem In UsersRoleList.Items
            Dim RoleCheckBox As CheckBox = CType(ri.FindControl("RoleCheckBox"), CheckBox)

            If (selectedUsersRoles.Contains(RoleCheckBox.Text)) Then
                RoleCheckBox.Checked = True
            Else
                RoleCheckBox.Checked = False
            End If
        Next

    End Sub

    Private Sub DisplayUsersBelongingToRole()

        Dim selectedRoleName As String = RoleList.SelectedValue
        Dim usersBelongingToRole As String() = Roles.GetUsersInRole(selectedRoleName)
        RolesUserList.DataSource = usersBelongingToRole
        RolesUserList.DataBind()

    End Sub

    Private Sub RolesUserList_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles RolesUserList.RowDeleting

        Dim selectedRoleName As String = RoleList.SelectedValue

        Dim UserNameLabel As Label = CType(RolesUserList.Rows(e.RowIndex).FindControl("UserNameLabel"), Label)
        Roles.RemoveUserFromRole(UserNameLabel.Text, selectedRoleName)
        DisplayUsersBelongingToRole()
        ActionStatus2.Text = String.Format("Usuario {0} se le removió el permiso {1}.", UserNameLabel.Text, selectedRoleName)

        upP.Focus()
        RoleList.Focus()
        CheckRolesForSelectedUser()

    End Sub

    Protected Sub AddUserToRoleButton_Click(ByVal sender As Object, ByVal e As EventArgs) Handles AddUserToRoleButton.Click

        Dim selectedRoleName As String = RoleList.SelectedValue
        Dim userNameToAddToRoleS As String = UserNameToAddToRole.Text


        If (userNameToAddToRoleS.Trim().Length = 0) Then
            ActionStatus2.Text = "Debe ingresar un usuario."
            Return
        End If

        Dim userInfo As MembershipUser = Membership.GetUser(userNameToAddToRoleS)
        If (IsNothing(userInfo)) Then
            ActionStatus2.Text = String.Format("El usuario {0} no existe en el sistema.", userNameToAddToRoleS)
            Return
        End If

        If (Roles.IsUserInRole(userNameToAddToRoleS, selectedRoleName)) Then
            ActionStatus2.Text = String.Format("Usuario {0} ya tiene asociado el permiso {1}.", userNameToAddToRoleS, selectedRoleName)
            Return
        End If



        Roles.AddUserToRole(userNameToAddToRoleS, selectedRoleName)
        UserNameToAddToRole.Text = String.Empty
        DisplayUsersBelongingToRole()
        ActionStatus2.Text = String.Format("Usuario {0} se le asignó el permiso {1}.", userNameToAddToRoleS, selectedRoleName)
        agregarBitacora(String.Format("Usuario {0} se le asignó el permiso {1}.", userNameToAddToRoleS, selectedRoleName))
        upP.Focus()
        UserNameToAddToRole.Focus()
        CheckRolesForSelectedUser()

    End Sub

    Private Property UsernameToMatch() As String

        Get
            Dim o As Object = ViewState("UsernameToMatch")
            If o Is Nothing Then
                Return String.Empty
            Else
                Return o.ToString()
            End If
        End Get

        Set(ByVal Value As String)
            ViewState("UsernameToMatch") = Value
        End Set

    End Property

    Private Sub RoleList_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles RoleList.SelectedIndexChanged

        DisplayUsersBelongingToRole()

    End Sub



    Private Sub unblockUser_Click(sender As Object, e As EventArgs) Handles unblockUser.Click

        Try

            Dim mu As MembershipUser = Membership.GetUser(UserList.SelectedValue)

            mu.UnlockUser()

            Membership.UpdateUser(mu)

            ActionStatus.Text = String.Format("Usuario {0} se ha desbloqueado con éxito.", UserList.SelectedValue)

            unblockUser.Enabled = False

        Catch ex As Exception
            ActionStatus.Text = String.Format("Error al desbloquear el usuario {0}.", UserList.SelectedValue)
        End Try

    End Sub



    Private Sub asignarTodos_Click(sender As Object, e As EventArgs) Handles asignarTodos.Click

        Dim rols As String() = Roles.GetAllRoles

        Dim lista = rols.Where(Function(p) p.StartsWith("Sie"))

        For Each ele In lista

            If (Not Roles.IsUserInRole(UserList.SelectedValue, ele)) Then
                Roles.AddUserToRole(UserList.SelectedValue, ele)
            End If
        Next

        CheckRolesForSelectedUser()

    End Sub



    Private Sub eliminarTodos_Click(sender As Object, e As EventArgs) Handles eliminarTodos.Click

        Dim rols As String() = Roles.GetAllRoles

        Dim lista = rols.Where(Function(p) p.StartsWith("Sie"))

        For Each ele In lista
            If (Roles.IsUserInRole(UserList.SelectedValue, ele)) Then
                Roles.RemoveUserFromRole(UserList.SelectedValue, ele)
            End If
        Next

        CheckRolesForSelectedUser()

    End Sub

    Private Sub UserList_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles UserList.SelectedIndexChanged

        CheckRolesForSelectedUser()
        UserList.Focus()

    End Sub

    Private Sub agregarBitacora(ByVal cadena As String)

        'Using bitacoraService As New BitacoraService.BitacoraServiceClient("BasicHttpBinding_IBitacoraService")

        '    bitacoraService.Insertar(User.Identity.Name, Request.Url.AbsolutePath, User.Identity.Name, Date.Now, cadena)

        'End Using

    End Sub

    Protected Sub RoleCheckBox_CheckedChanged(sender As Object, e As EventArgs)
        Dim RoleCheckBox As CheckBox = CType(sender, CheckBox)
        Dim selectedUserName As String = UserList.SelectedValue
        Dim roleName As String = RoleCheckBox.Text
        If (RoleCheckBox.Checked) Then
            If (Roles.IsUserInRole(selectedUserName, roleName)) Then
                ActionStatus.Text = String.Format("Usuario {0} ya está asignado el permiso {1}.", selectedUserName, roleName)
            Else
                Roles.AddUserToRole(selectedUserName, roleName)
                ActionStatus.Text = String.Format("Usuario {0} se le ha asignado el permiso {1}.", selectedUserName, roleName)
                agregarBitacora(String.Format("Usuario {0} se le ha asignado el permiso {1}.", selectedUserName, roleName))
            End If

        Else

            If (Roles.IsUserInRole(selectedUserName, roleName)) Then
                Roles.RemoveUserFromRole(selectedUserName, roleName)
                ActionStatus.Text = String.Format("Usuario {0} se le removió el permiso {1}.", selectedUserName, roleName)
                agregarBitacora(String.Format("Usuario {0} se le removió el permiso {1}.", selectedUserName, roleName))
            Else
                ActionStatus.Text = String.Format("Usuario {0} no tiene asignado el permiso {1}.", selectedUserName, roleName)
            End If

        End If

        upL.Focus()
        UsersRoleList.Focus()
        RoleCheckBox.Focus()
        DisplayUsersBelongingToRole()
    End Sub


End Class