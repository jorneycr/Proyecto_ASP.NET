﻿var report_server = "http://sbd1/ReportServer";



function OnCancelar(id) {

    document.getElementById(id).click();

}



var clientid;

var tipo;

function fnSetFocus(txtClientId, tipoParam) {

    clientid = txtClientId;

    tipo = tipoParam;

    setTimeout("fnFocus()", 1000);

}



function fnFocus() {

    try {

        var objeto = $find(clientid);

        if (tipo == null) {

            tipo = 1;

        }

        if (objeto == null) {

            objeto = document.getElementById(clientid);

        }

        if (objeto != null) {

            if (tipo == 1) {

                objeto.focus();

            } else {

                if (tipo == 2) {

                    objeto._element.focus();

                } else {

                    if (tipo == 3) {

                        objeto.get_dateInput().focus();

                    } else {

                        if (tipo == 4) {

                            objeto.get_inputDomElement().focus();

                        }

                    }

                }

            }

            return false;

        }

    } catch (e) { }

}



var clientidSet;

var valorSet;

function fnSetValue(txtClientId, valor) {

    clientidSet = txtClientId;

    valorSet = valor;

    setTimeout("fnSet()", 1000);

}



function fnSet() {

    try {

        eval("document.getElementById('" + clientidSet + "').value = ");

    } catch (e) { }

}



function siguiente(objId) {

    siguiente(null, objId, null);

}



function limpiarFoco(obj) {

    try {

        obj.firstElementChild.className = 'rddlInner';

    } catch (e) { }

}



//1 es radTextBox

//2 es RadDropDownList

//3 es DatePicker

//4 es RadCombobox

function siguiente(origen, objId, tipoDestino) {

    try {

        if (objId == null) {

            objId = "";

        }

        var key = event.keyCode || event.which;

        if (key == 13) {

            if (objId != "") {

                limpiarFoco(origen);



                var objeto = $find(objId);

                if (tipoDestino == null) {

                    tipoDestino = 1;

                }

                if (objeto == null) {

                    objeto = document.getElementById(objId);

                }

                if (objeto != null) {

                    if (tipoDestino == 1) {

                        objeto.focus();

                    } else {

                        if (tipoDestino == 2) {

                            objeto._element.focus();

                        } else {

                            if (tipoDestino == 3) {

                                objeto.get_dateInput().focus();

                            } else {

                                if (tipoDestino == 4) {

                                    objeto.get_inputDomElement().focus();

                                }

                            }

                        }

                    }

                    return false;

                }

                return false;

            } else {

                //try {

                //    if (origen != null) {

                //        alert(origen.nextSibling);

                //        var obj = next(origen);

                //        alert(obj);

                //        if (obj != null) {

                //            obj.focus();

                //        }

                //    }

                //} catch (e) { alert(e); };

                return false;

            }

        }

    } catch (e) {

        alert(e.message);

        return false;

    }

    return true;

}



function next(elem) {

    do {

        elem = elem.nextSibling;

    } while (elem && elem.nodeType !== 1);

    return elem;

}



function mis_datos(obj, editable, objIdSiguiente, tipoDestino) {

    var key = event.keyCode || event.which;

    //Manejamos el enter

    if (key == 13) {

        return siguiente(obj, objIdSiguiente, tipoDestino);

    }

    //Verificamos que no haga backspace en un dropdown

    var type = getType(obj);

    if (type == 2) {

        if (key == 8) {

            return false;

        }

    }

    //Verificamos teclas de no edición

    //Tab, enter, shift, ctrl, alt,pause,capslock,escape,page up,pagedown,end,home,left arrow,up arrow,right arrow,down arrow

    var llavesPermitidas = new Array(9, 13, 16, 17, 18, 19, 20, 27, 33, 34, 35, 36, 37, 38, 39, 40);

    var correcta = false;

    for (i = 0; i < llavesPermitidas.length; i++) {

        if (key == llavesPermitidas[i]) {

            return true;

        }

    }

    //Si es editable permitimos el backspace o el delete

    if (editable) {

        if (key == 8 || key == 46) {

            return true;

        }

    } else {

        //Si no es editable regresamos

        return false;

    }



    //Retornamos verdadero al final, pues este método valida alfanuméricos

    return true;

}



function getType(control) {  //1 texto 2 combo 3 no definido

    if (control != null && control.type == "text") {

        //control is textbox

        return 1;

    }

    else {

        if (control != null && control.type == "select-one") {

            //control is dropdownlist

            return 2;

        }

    }

    return 3;

}//function end





function mis_datos_numericos(obj, decimal, editable, objIdSiguiente, tipoDestino) {

    var key = event.keyCode || event.which;

    //Manejo el enter

    if (key == 13) {

        return siguiente(obj, objIdSiguiente, tipoDestino);

    }

    //Verificamos que no haga backspace en un dropdown

    var type = getType(obj);

    if (type == 2) {

        if (key == 8) {

            return false;

        }

    }

    //Verificamos teclas de no edición

    //Tab, enter, shift, ctrl, alt,pause,capslock,escape,page up,pagedown,end,home,left arrow,up arrow,right arrow,down arrow

    var llavesPermitidas = new Array(9, 13, 16, 17, 18, 19, 20, 27, 33, 34, 35, 36, 37, 38, 39, 40);

    var correcta = false;

    for (i = 0; i < llavesPermitidas.length; i++) {

        if (key == llavesPermitidas[i]) {

            return true;

        }

    }

    //Verificamos el punto decimal

    if (editable && decimal) {

        if (key == 190 || key == 110) {

            return true;

        }

    }

    //Si es editable permitimos el backspace o el delete

    if (editable) {

        if (key == 8 || key == 46) {

            return true;

        }

    } else {

        //Si no es editable regresamos

        return false;

    }

    //Al ser un metodo numérico verificamos las teclas de número



    if (key >= 48 && key <= 57)

        return true;

    if (key >= 96 && key <= 105)

        return true;



    //Devolvemos false si no logramos verificar los números  

    return false;

}



function unformat(obj) {

    //obj.value = obj.value.replaceAll(",", "");

    obj.value = obj.value.split(',').join('')

    obj.select();

}