﻿Imports System.ServiceModel

' NOTA: puede usar el comando "Cambiar nombre" del menú contextual para cambiar el nombre de interfaz "ISie_services" en el código y en el archivo de configuración a la vez.
<ServiceContract()>
Public Interface ISie_services
    'Categoria
    <OperationContract()>
    Function InsertarCategoria(ByVal categoria As Categoria) As RespuestaGenerica
    <OperationContract()>
    Function ModificarCategoria(ByVal categoria As Categoria) As RespuestaGenerica
    <OperationContract()>
    Function EliminarCategoria(ByVal numero_categoria As Integer) As RespuestaGenerica
    <OperationContract()>
    Function ObtenerCategorias() As List(Of Categoria)

    'Equipo
    <OperationContract()>
    Function InsertarEquipo(ByVal equipo As Equipo) As RespuestaGenerica

    <OperationContract()>
    Function ModificarEquipo(ByVal equipo As Equipo) As RespuestaGenerica

    <OperationContract()>
    Function EliminarEquipo(ByVal numero_equipo As Integer) As RespuestaGenerica

    <OperationContract()>
    Function ObtenerEquipo() As List(Of Equipo)

    'Empleado
    <OperationContract()>
    Function ObtenerEmpleado() As List(Of EmpleadoClase)

    <OperationContract()>
    Function ObtenerEmpleadoPorParametro(ByVal numero_empleado As String) As List(Of EmpleadoClase)

    'Departamento
    <OperationContract()>
    Function InsertarDepartamento(ByVal departamento As Departamento) As RespuestaGenerica

    <OperationContract()>
    Function ModificarDepartamento(ByVal departamento As Departamento) As RespuestaGenerica

    <OperationContract()>
    Function EliminarDepartamento(ByVal numero_departamento As Integer) As RespuestaGenerica

    <OperationContract()>
    Function ObtenerDepartamento() As List(Of Departamento)

    'Historial Equipo
    <OperationContract()>
    Function InsertarEquipoHistorial(ByVal historial As Historial) As RespuestaGenerica

    <OperationContract()>
    Function ObtenerEquipoHistorial() As List(Of Historial)

    'Area
    <OperationContract()>
    Function InsertarArea(ByVal area As AreaClase) As RespuestaGenerica
    <OperationContract()>
    Function ModificarArea(ByVal area As AreaClase) As RespuestaGenerica
    <OperationContract()>
    Function EliminarArea(ByVal numero_area As Integer) As RespuestaGenerica
    <OperationContract()>
    Function ObtenerArea() As List(Of AreaClase)

    'SIM
    <OperationContract()>
    Function InsertarSIM(ByVal sim As SIM) As RespuestaGenerica
    <OperationContract()>
    Function ModificarSIM(ByVal sim As SIM) As RespuestaGenerica
    <OperationContract()>
    Function EliminarSIM(ByVal numero_sim As Integer) As RespuestaGenerica
    <OperationContract()>
    Function ObtenerSIM() As List(Of SIM)

    'Otros Metodos
    <OperationContract()>
    Function obtenerNumero(serviceTag As String)

    <OperationContract()>
    Function ObtenerEmpleadoPorNombre(codigo As String) As String

    <OperationContract()>
    Function ObtenerCategoriaPorNombre(codigo As Integer) As String

    <OperationContract()>
    Function ObtenerCategoriaPorParametro(ByVal numero_categoria As Integer) As List(Of Categoria)


End Interface

Public Class Equipo
    <DataMember()>
    Public Property numero_equipo As Integer

    <DataMember()>
    Public Property service_tag As String

    <DataMember()>
    Public Property numero_categoria As Integer

    <DataMember()>
    Public Property numero_empleado As String

    <DataMember()>
    Public Property numero_departamento As Integer

    <DataMember()>
    Public Property numero_area As Integer

    <DataMember()>
    Public Property marca As String

    <DataMember()>
    Public Property modelo As String

    <DataMember()>
    Public Property procesador As String

    <DataMember()>
    Public Property ram As String

    <DataMember()>
    Public Property disco As String

    <DataMember()>
    Public Property pantalla As String

    <DataMember()>
    Public Property puertos As String

    <DataMember()>
    Public Property otros As String

    <DataMember()>
    Public Property tipo As String

    <DataMember()>
    Public Property descripcion As String

    <DataMember()>
    Public Property os As String

    <DataMember()>
    Public Property usuario_creacion As String

    <DataMember()>
    Public Property fecha_creacion As Date
    <DataMember()>
    Public Property usuario_modificacion As String
    <DataMember()>
    Public Property fecha_modificacion As Nullable(Of Date)
End Class

Public Class Categoria
    <DataMember()>
    Public Property numero_categoria As Integer
    <DataMember()>
    Public Property categoria As String
    <DataMember()>
    Public Property usuario_creacion As String
    <DataMember()>
    Public Property fecha_creacion As Date
    <DataMember()>
    Public Property usuario_modificacion As String
    <DataMember()>
    Public Property fecha_modificacion As Nullable(Of Date)
End Class

Public Class Historial
    <DataMember()>
    Public Property numero_historial As Integer

    <DataMember()>
    Public Property numero_equipo As Integer

    <DataMember()>
    Public Property service_tag As String

    <DataMember()>
    Public Property numero_categoria As Integer

    <DataMember()>
    Public Property numero_empleado As String

    <DataMember()>
    Public Property numero_departamento As Integer

    <DataMember()>
    Public Property numero_area As Integer

    <DataMember()>
    Public Property marca As String

    <DataMember()>
    Public Property modelo As String

    <DataMember()>
    Public Property procesador As String

    <DataMember()>
    Public Property ram As String

    <DataMember()>
    Public Property disco As String

    <DataMember()>
    Public Property pantalla As String

    <DataMember()>
    Public Property puertos As String

    <DataMember()>
    Public Property otros As String

    <DataMember()>
    Public Property os As String

    <DataMember()>
    Public Property tipo As String

    <DataMember()>
    Public Property descripcion As String

    <DataMember()>
    Public Property usuario_creacion As String

    <DataMember()>
    Public Property fecha_creacion As Date

    <DataMember()>
    Public Property usuario_modificacion As String

    <DataMember()>
    Public Property fecha_modificacion As Nullable(Of Date)

End Class

Public Class EmpleadoClase
    <DataMember()>
    Public Property numero_empleado As String

    <DataMember()>
    Public Property empleado As String
End Class

Public Class AreaClase
    <DataMember()>
    Public Property numero_Area As Integer


    <DataMember()>
    Public Property Area As String


    <DataMember()>
    Public Property usuario_creacion As String

    <DataMember()>
    Public Property fecha_creacion As Date

    <DataMember()>
    Public Property usuario_modificacion As String

    <DataMember()>
    Public Property fecha_modificacion As Nullable(Of Date)

End Class

Public Class Departamento
    <DataMember()>
    Public Property numero_departamento As Integer

    <DataMember()>
    Public Property departamento As String

    <DataMember()>
    Public Property usuario_creacion As String

    <DataMember()>
    Public Property fecha_creacion As Date

    <DataMember()>
    Public Property usuario_modificacion As String

    <DataMember()>
    Public Property fecha_modificacion As Nullable(Of Date)

End Class

Public Class SIM
    <DataMember()>
    Public Property numero_sim As Integer

    <DataMember()>
    Public Property asignado As String

    <DataMember()>
    Public Property numero_telefono As String

    <DataMember()>
    Public Property numero_serie As String

    <DataMember()>
    Public Property pin As String

    <DataMember()>
    Public Property punk As String

    <DataMember()>
    Public Property usuario_creacion As String

    <DataMember()>
    Public Property fecha_creacion As Date

    <DataMember()>
    Public Property usuario_modificacion As String

    <DataMember()>
    Public Property fecha_modificacion As Nullable(Of Date)
End Class

Public Class RespuestaGenerica
    <DataMember()>
    Public Property exito As Boolean
    <DataMember()>
    Public Property mensaje As String
End Class