﻿' NOTA: puede usar el comando "Cambiar nombre" del menú contextual para cambiar el nombre de clase "Sie_services" en el código, en svc y en el archivo de configuración a la vez.
' NOTA: para iniciar el Cliente de prueba WCF para probar este servicio, seleccione Sie_services.svc o Sie_services.svc.vb en el Explorador de soluciones e inicie la depuración.
Imports Sie_Services

Public Class Sie_services
    Implements ISie_services

    'Categoria
    Public Function InsertarCategoria(categoria As Categoria) As RespuestaGenerica Implements ISie_services.InsertarCategoria
        Dim respuesta As RespuestaGenerica
        Try
            Dim contexto As New SieEntities
            Dim nuevaCategoria As New Sie_Equipo_Categoria
            nuevaCategoria.Categoria = categoria.categoria
            nuevaCategoria.Usuario_Creacion = categoria.usuario_creacion
            nuevaCategoria.Fecha_creacion = Date.Now
            contexto.Sie_Equipo_Categoria.Add(nuevaCategoria)
            contexto.SaveChanges()

            respuesta = New RespuestaGenerica
            respuesta.exito = True
            respuesta.mensaje = "El registro se inserto correctamente"
        Catch ex As Exception
            respuesta = New RespuestaGenerica
            respuesta.exito = False
            respuesta.mensaje = ex.Message.ToString
        End Try
        Return respuesta
    End Function

    Public Function ModificarCategoria(categoria As Categoria) As RespuestaGenerica Implements ISie_services.ModificarCategoria
        Dim respuesta As RespuestaGenerica
        Try
            Dim contexto As New SieEntities
            Dim modificar = contexto.Sie_Equipo_Categoria.Where(Function(p) p.Numero_Categoria = categoria.numero_categoria).SingleOrDefault
            'Dim modificar = (From c In contexto.Sie_Categoria Where c.Numero_Categoria = categoria.numero_categoria Select c).SingleOrDefault
            modificar.Categoria = categoria.categoria
            modificar.Usuario_Modificacion = categoria.usuario_modificacion
            modificar.Fecha_modificacion = Date.Now
            contexto.SaveChanges()

            respuesta = New RespuestaGenerica
            respuesta.exito = True
            respuesta.mensaje = "El registro se modifico correctamente"
        Catch ex As Exception
            respuesta = New RespuestaGenerica
            respuesta.exito = False
            respuesta.mensaje = ex.Message.ToString
        End Try
        Return respuesta
    End Function

    Public Function EliminarCategoria(numero_categoria As Integer) As RespuestaGenerica Implements ISie_services.EliminarCategoria
        Dim respuesta As RespuestaGenerica
        Try
            Dim contexto As New SieEntities
            Dim eliminar = contexto.Sie_Equipo_Categoria.Where(Function(p) p.Numero_Categoria = numero_categoria).SingleOrDefault
            'Dim modificar = (From c In contexto.Sie_Categoria Where c.Numero_Categoria = categoria.numero_categoria Select c).SingleOrDefault
            contexto.Sie_Equipo_Categoria.Remove(eliminar)
            contexto.SaveChanges()

            respuesta = New RespuestaGenerica
            respuesta.exito = True
            respuesta.mensaje = "El registro se elimino correctamente"
        Catch ex As Exception
            respuesta = New RespuestaGenerica
            respuesta.exito = False
            respuesta.mensaje = ex.Message.ToString
        End Try
        Return respuesta
    End Function

    Public Function ObtenerCategorias() As List(Of Categoria) Implements ISie_services.ObtenerCategorias
        Dim listacategorias As New List(Of Categoria)
        Try
            Dim contexto As New SieEntities

            Dim categorias = contexto.Sie_Equipo_Categoria
            For Each categoria In categorias
                Dim itemCategoria As New Categoria
                itemCategoria.numero_categoria = categoria.Numero_Categoria
                itemCategoria.categoria = categoria.Categoria
                itemCategoria.fecha_creacion = categoria.Fecha_creacion
                itemCategoria.usuario_creacion = categoria.Usuario_Creacion
                itemCategoria.fecha_modificacion = categoria.Fecha_modificacion
                itemCategoria.usuario_modificacion = categoria.Usuario_Modificacion
                listacategorias.Add(itemCategoria)
            Next
        Catch ex As Exception

        End Try
        Return listacategorias
    End Function

    'Equipo
    Public Function InsertarEquipo(equipo As Equipo) As RespuestaGenerica Implements ISie_services.InsertarEquipo
        Dim respuesta As New RespuestaGenerica
        Try
            Dim contexto As New SieEntities
            Dim nuevoEquipo As New Sie_Equipo
            nuevoEquipo.Service_Tag = equipo.service_tag
            nuevoEquipo.Numero_Categoria = equipo.numero_categoria
            nuevoEquipo.Numero_Empleado = equipo.numero_empleado
            nuevoEquipo.Numero_Departamento = equipo.numero_departamento
            nuevoEquipo.Numero_Area = equipo.numero_area
            nuevoEquipo.Marca = equipo.marca
            nuevoEquipo.Modelo = equipo.modelo
            nuevoEquipo.Procesador = equipo.procesador
            nuevoEquipo.RAM = equipo.ram
            nuevoEquipo.Disco_Duro = equipo.disco
            nuevoEquipo.Pantalla = equipo.pantalla
            nuevoEquipo.Puertos = equipo.puertos
            nuevoEquipo.Otros = equipo.otros
            nuevoEquipo.Tipo = equipo.tipo
            nuevoEquipo.Descripcion = equipo.descripcion
            nuevoEquipo.OS = equipo.os
            nuevoEquipo.Usuario_Creacion = equipo.usuario_creacion
            nuevoEquipo.Fecha_creacion = Date.Now
            contexto.Sie_Equipo.Add(nuevoEquipo)
            contexto.SaveChanges()

            respuesta = New RespuestaGenerica
            respuesta.exito = True
            respuesta.mensaje = "El registro se inserto con exito"
        Catch ex As Exception
            respuesta = New RespuestaGenerica
            respuesta.exito = False
            respuesta.mensaje = ex.Message.ToString
        End Try
        Return respuesta
    End Function

    Public Function ModificarEquipo(equipo As Equipo) As RespuestaGenerica Implements ISie_services.ModificarEquipo
        Dim respuesta As RespuestaGenerica
        Try
            Dim contexto As New SieEntities
            Dim modificar = contexto.Sie_Equipo.Where(Function(p) p.Numero_Equipo = equipo.numero_equipo).SingleOrDefault
            'Dim modificar = (From c In contexto.Sie_Categoria Where c.Numero_Categoria = categoria.numero_categoria Select c).SingleOrDefault
            modificar.Numero_Categoria = equipo.numero_categoria
            modificar.Numero_Empleado = equipo.numero_empleado
            modificar.Numero_Departamento = equipo.numero_departamento
            modificar.Numero_Area = equipo.numero_area
            modificar.Marca = equipo.marca
            modificar.Modelo = equipo.modelo
            modificar.Procesador = equipo.procesador
            modificar.RAM = equipo.ram
            modificar.Disco_Duro = equipo.disco
            modificar.Pantalla = equipo.pantalla
            modificar.Puertos = equipo.puertos
            modificar.Otros = equipo.otros
            modificar.Tipo = equipo.tipo
            modificar.Descripcion = equipo.descripcion
            modificar.OS = equipo.os
            modificar.Usuario_Modificacion = equipo.usuario_modificacion
            modificar.Fecha_modificacion = Date.Now
            contexto.SaveChanges()

            respuesta = New RespuestaGenerica
            respuesta.exito = True
            respuesta.mensaje = "El registro se modifico correctamente"
        Catch ex As Exception
            respuesta = New RespuestaGenerica
            respuesta.exito = False
            respuesta.mensaje = ex.Message.ToString
        End Try
        Return respuesta
    End Function

    Public Function EliminarEquipo(numero_equipo As Integer) As RespuestaGenerica Implements ISie_services.EliminarEquipo
        Dim respuesta As RespuestaGenerica
        Try
            Dim contexto As New SieEntities
            Dim eliminar = contexto.Sie_Equipo.Where(Function(p) p.Numero_Equipo = numero_equipo).SingleOrDefault
            'Dim modificar = (From c In contexto.Sie_Categoria Where c.Numero_Categoria = categoria.numero_categoria Select c).SingleOrDefault
            contexto.Sie_Equipo.Remove(eliminar)
            contexto.SaveChanges()

            respuesta = New RespuestaGenerica
            respuesta.exito = True
            respuesta.mensaje = "El registro se elimino correctamente"
        Catch ex As Exception
            respuesta = New RespuestaGenerica
            respuesta.exito = False
            respuesta.mensaje = ex.Message.ToString
        End Try
        Return respuesta
    End Function

    Public Function ObtenerEquipo() As List(Of Equipo) Implements ISie_services.ObtenerEquipo
        Dim listaequipo As New List(Of Equipo)
        Try
            Dim contexto As New SieEntities
            Dim equipos = contexto.Sie_Equipo
            For Each equipo In equipos
                Dim itemEquipos As New Equipo
                itemEquipos.numero_equipo = equipo.Numero_Equipo
                itemEquipos.service_tag = equipo.Service_Tag
                itemEquipos.numero_categoria = equipo.Numero_Categoria
                itemEquipos.numero_empleado = equipo.Numero_Empleado
                itemEquipos.numero_departamento = equipo.Numero_Departamento
                itemEquipos.numero_area = equipo.Numero_Area
                itemEquipos.marca = equipo.Marca
                itemEquipos.modelo = equipo.Modelo
                itemEquipos.procesador = equipo.Procesador
                itemEquipos.ram = equipo.RAM
                itemEquipos.disco = equipo.Disco_Duro
                itemEquipos.pantalla = equipo.Pantalla
                itemEquipos.puertos = equipo.Puertos
                itemEquipos.otros = equipo.Otros
                itemEquipos.tipo = equipo.Tipo
                itemEquipos.descripcion = equipo.Descripcion
                itemEquipos.os = equipo.OS
                itemEquipos.fecha_creacion = equipo.Fecha_creacion
                itemEquipos.usuario_creacion = equipo.Usuario_Creacion
                itemEquipos.fecha_modificacion = equipo.Fecha_modificacion
                itemEquipos.usuario_modificacion = equipo.Usuario_Modificacion
                listaequipo.Add(itemEquipos)
            Next
        Catch ex As Exception

        End Try
        Return listaequipo
    End Function


    'Historial
    Public Function InsertarEquipoHistorial(Historial As Historial) As RespuestaGenerica Implements ISie_services.InsertarEquipoHistorial
        Dim respuesta As New RespuestaGenerica
        Try
            Dim contexto As New SieEntities
            Dim nuevoEquipo As New Sie_Historial
            nuevoEquipo.Numero_Equipo = Historial.numero_equipo
            nuevoEquipo.Service_Tag = Historial.service_tag
            nuevoEquipo.Marca = Historial.marca
            nuevoEquipo.Modelo = Historial.modelo
            nuevoEquipo.Tipo = Historial.tipo
            nuevoEquipo.Procesador = Historial.procesador
            nuevoEquipo.RAM = Historial.ram
            nuevoEquipo.Disco_Duro = Historial.disco
            nuevoEquipo.Pantalla = Historial.pantalla
            nuevoEquipo.Puertos = Historial.puertos
            nuevoEquipo.OS = Historial.os
            nuevoEquipo.Otros = Historial.otros
            nuevoEquipo.Descripcion = Historial.descripcion
            nuevoEquipo.Numero_Categoria = Historial.numero_categoria
            nuevoEquipo.Numero_Empleado = Historial.numero_empleado
            nuevoEquipo.Numero_Departamento = Historial.numero_departamento
            nuevoEquipo.Numero_Area = Historial.numero_area
            nuevoEquipo.Usuario_Creacion = Historial.usuario_creacion
            nuevoEquipo.Fecha_creacion = Date.Now
            contexto.Sie_Historial.Add(nuevoEquipo)
            contexto.SaveChanges()

            respuesta = New RespuestaGenerica
            respuesta.exito = True
            respuesta.mensaje = "El registro se inserto con exito"
        Catch ex As Exception
            respuesta = New RespuestaGenerica
            respuesta.exito = False
            respuesta.mensaje = ex.Message.ToString
        End Try
        Return respuesta
    End Function

    Public Function ObtenerEquipoHistorial() As List(Of Historial) Implements ISie_services.ObtenerEquipoHistorial
        Dim listaequipo As New List(Of Historial)
        Try
            Dim contexto As New SieEntities
            Dim EquipoHistorial = contexto.Sie_Historial
            For Each EquiposHistorial In EquipoHistorial
                Dim itemEquipos As New Historial
                itemEquipos.numero_historial = EquiposHistorial.Numero_Historial
                itemEquipos.numero_equipo = EquiposHistorial.Numero_Equipo
                itemEquipos.service_tag = EquiposHistorial.Service_Tag
                itemEquipos.numero_categoria = EquiposHistorial.Numero_Categoria
                itemEquipos.numero_empleado = EquiposHistorial.Numero_Empleado
                itemEquipos.numero_departamento = EquiposHistorial.Numero_Departamento
                itemEquipos.numero_area = EquiposHistorial.Numero_Area
                itemEquipos.marca = EquiposHistorial.Marca
                itemEquipos.modelo = EquiposHistorial.Modelo
                itemEquipos.procesador = EquiposHistorial.Procesador
                itemEquipos.ram = EquiposHistorial.RAM
                itemEquipos.disco = EquiposHistorial.Disco_Duro
                itemEquipos.pantalla = EquiposHistorial.Pantalla
                itemEquipos.puertos = EquiposHistorial.Puertos
                itemEquipos.otros = EquiposHistorial.Otros
                itemEquipos.tipo = EquiposHistorial.Tipo
                itemEquipos.os = EquiposHistorial.OS
                itemEquipos.descripcion = EquiposHistorial.Descripcion
                itemEquipos.fecha_creacion = EquiposHistorial.Fecha_creacion
                itemEquipos.usuario_creacion = EquiposHistorial.Usuario_Creacion
                itemEquipos.fecha_modificacion = EquiposHistorial.Fecha_modificacion
                itemEquipos.usuario_modificacion = EquiposHistorial.Usuario_Modificacion
                listaequipo.Add(itemEquipos)
            Next
        Catch ex As Exception

        End Try
        Return listaequipo
    End Function

    'Exactus
    Public Function ObtenerEmpleado() As List(Of EmpleadoClase) Implements ISie_services.ObtenerEmpleado
        Dim listaEmpleado As New List(Of EmpleadoClase)
        Try
            Dim contexto As New Exactus6Entities

            Dim Empleados = contexto.EMPLEADO
            For Each Empleado In Empleados
                Dim itemEmpleado As New EmpleadoClase
                itemEmpleado.numero_empleado = Empleado.EMPLEADO1
                itemEmpleado.empleado = Empleado.NOMBRE
                listaEmpleado.Add(itemEmpleado)
            Next
        Catch ex As Exception

        End Try
        Return listaEmpleado
    End Function

    Public Function ObtenerEmpleadoPorNombre(codigo As String) As String Implements ISie_services.ObtenerEmpleadoPorNombre
        Dim nombre As String
        Try
            Dim contexto As New Exactus6Entities
            Dim registro = (From t In contexto.EMPLEADO Where t.EMPLEADO1.Equals(codigo) Select t).FirstOrDefault
            If Not IsNothing(registro) Then
                nombre = registro.NOMBRE
            End If
        Catch ex As Exception

        End Try
        Return nombre
    End Function

    Public Function ObtenerEmpleadoPorParametro(numero_empleado As String) As List(Of EmpleadoClase) Implements ISie_services.ObtenerEmpleadoPorParametro

        Dim listaEmpleado As New List(Of EmpleadoClase)
        Try
            Dim contexto As New Exactus6Entities
            Dim registro = (From t In contexto.EMPLEADO Where t.EMPLEADO1.Equals(numero_empleado) Select t).FirstOrDefault
            Dim Empleados = registro

            Dim itemEmpleado As New EmpleadoClase
            itemEmpleado.numero_empleado = Empleados.EMPLEADO1
            itemEmpleado.empleado = Empleados.NOMBRE
            listaEmpleado.Add(itemEmpleado)

        Catch ex As Exception

        End Try
        Return listaEmpleado
    End Function

    'Departamento
    Public Function InsertarDepartamento(departamento As Departamento) As RespuestaGenerica Implements ISie_services.InsertarDepartamento
        Dim respuesta As New RespuestaGenerica
        Try
            Dim contexto As New SieEntities
            Dim nuevoDepartamento As New Sie_Departamento
            nuevoDepartamento.Departamento = departamento.departamento
            nuevoDepartamento.Usuario_Creacion = departamento.usuario_creacion
            nuevoDepartamento.Fecha_creacion = Date.Now
            contexto.Sie_Departamento.Add(nuevoDepartamento)
            contexto.SaveChanges()

            respuesta = New RespuestaGenerica
            respuesta.exito = True
            respuesta.mensaje = "El registro se inserto con exito"
        Catch ex As Exception
            respuesta = New RespuestaGenerica
            respuesta.exito = False
            respuesta.mensaje = ex.Message.ToString
        End Try
        Return respuesta
    End Function

    Public Function ModificarDepartamento(departamento As Departamento) As RespuestaGenerica Implements ISie_services.ModificarDepartamento
        Dim respuesta As RespuestaGenerica
        Try
            Dim contexto As New SieEntities
            Dim modificar = contexto.Sie_Departamento.Where(Function(p) p.Numero_Departamento = departamento.numero_departamento).SingleOrDefault
            'Dim modificar = (From c In contexto.Sie_Categoria Where c.Numero_Categoria = categoria.numero_categoria Select c).SingleOrDefault
            modificar.Numero_Departamento = departamento.numero_departamento
            modificar.Departamento = departamento.departamento
            modificar.Usuario_Modificacion = departamento.usuario_modificacion
            modificar.Fecha_modificacion = Date.Now
            contexto.SaveChanges()

            respuesta = New RespuestaGenerica
            respuesta.exito = True
            respuesta.mensaje = "El registro se modifico correctamente"
        Catch ex As Exception
            respuesta = New RespuestaGenerica
            respuesta.exito = False
            respuesta.mensaje = ex.Message.ToString
        End Try
        Return respuesta
    End Function

    Public Function EliminarDepartamento(numero_departamento As Integer) As RespuestaGenerica Implements ISie_services.EliminarDepartamento
        Dim respuesta As RespuestaGenerica
        Try
            Dim contexto As New SieEntities
            Dim eliminar = contexto.Sie_Departamento.Where(Function(p) p.Numero_Departamento = numero_departamento).SingleOrDefault
            'Dim modificar = (From c In contexto.Sie_Categoria Where c.Numero_Categoria = categoria.numero_categoria Select c).SingleOrDefault
            contexto.Sie_Departamento.Remove(eliminar)
            contexto.SaveChanges()

            respuesta = New RespuestaGenerica
            respuesta.exito = True
            respuesta.mensaje = "El registro se elimino correctamente"
        Catch ex As Exception
            respuesta = New RespuestaGenerica
            respuesta.exito = False
            respuesta.mensaje = ex.Message.ToString
        End Try
        Return respuesta
    End Function

    Private Function ObtenerDepartamento() As List(Of Departamento) Implements ISie_services.ObtenerDepartamento
        Dim listadepartamento As New List(Of Departamento)
        Try
            Dim contexto As New SieEntities
            Dim departamentos = contexto.Sie_Departamento
            For Each departamento In departamentos
                Dim itemDepartamento As New Departamento
                itemDepartamento.numero_departamento = departamento.Numero_Departamento
                itemDepartamento.departamento = departamento.Departamento
                itemDepartamento.fecha_creacion = departamento.Fecha_creacion
                itemDepartamento.usuario_creacion = departamento.Usuario_Creacion
                itemDepartamento.fecha_modificacion = departamento.Fecha_modificacion
                itemDepartamento.usuario_modificacion = departamento.Usuario_Modificacion
                listadepartamento.Add(itemDepartamento)
            Next
        Catch ex As Exception

        End Try
        Return listadepartamento
    End Function

    'Area
    Public Function InsertarArea(area As AreaClase) As RespuestaGenerica Implements ISie_services.InsertarArea
        Dim respuesta As New RespuestaGenerica
        Try
            Dim contexto As New SieEntities
            Dim nuevoArea As New Sie_Area

            nuevoArea.Area = area.Area
            nuevoArea.Usuario_Creacion = area.usuario_creacion
            nuevoArea.Fecha_creacion = Date.Now
            contexto.Sie_Area.Add(nuevoArea)
            contexto.SaveChanges()

            respuesta = New RespuestaGenerica
            respuesta.exito = True
            respuesta.mensaje = "El registro se inserto con exito"
        Catch ex As Exception
            respuesta = New RespuestaGenerica
            respuesta.exito = False
            respuesta.mensaje = ex.Message.ToString
        End Try
        Return respuesta
    End Function

    Public Function ModificarArea(area As AreaClase) As RespuestaGenerica Implements ISie_services.ModificarArea
        Dim respuesta As RespuestaGenerica
        Try
            Dim contexto As New SieEntities
            Dim modificar = contexto.Sie_Area.Where(Function(p) p.Numero_Area = area.numero_Area).SingleOrDefault
            'Dim modificar = (From c In contexto.Sie_Categoria Where c.Numero_Categoria = categoria.numero_categoria Select c).SingleOrDefault
            modificar.Numero_Area = area.numero_Area
            modificar.Area = area.Area
            modificar.Usuario_Modificacion = area.usuario_modificacion
            modificar.Fecha_modificacion = Date.Now
            contexto.SaveChanges()

            respuesta = New RespuestaGenerica
            respuesta.exito = True
            respuesta.mensaje = "El registro se modifico correctamente"
        Catch ex As Exception
            respuesta = New RespuestaGenerica
            respuesta.exito = False
            respuesta.mensaje = ex.Message.ToString
        End Try
        Return respuesta
    End Function

    Private Function ISie_services_ObtenerArea() As List(Of AreaClase) Implements ISie_services.ObtenerArea
        Dim listaarea As New List(Of AreaClase)
        Try
            Dim contexto As New SieEntities
            Dim areas = contexto.Sie_Area
            For Each area In areas
                Dim itemArea As New AreaClase
                itemArea.numero_Area = area.Numero_Area
                itemArea.Area = area.Area
                itemArea.fecha_creacion = area.Fecha_creacion
                itemArea.usuario_creacion = area.Usuario_Creacion
                itemArea.fecha_modificacion = area.Fecha_modificacion
                itemArea.usuario_modificacion = area.Usuario_Modificacion
                listaarea.Add(itemArea)
            Next
        Catch ex As Exception

        End Try
        Return listaarea
    End Function

    Public Function EliminarArea(numero_area As Integer) As RespuestaGenerica Implements ISie_services.EliminarArea
        Dim respuesta As RespuestaGenerica
        Try
            Dim contexto As New SieEntities
            Dim eliminar = contexto.Sie_Area.Where(Function(p) p.Numero_Area = numero_area).SingleOrDefault
            'Dim modificar = (From c In contexto.Sie_Categoria Where c.Numero_Categoria = categoria.numero_categoria Select c).SingleOrDefault
            contexto.Sie_Area.Remove(eliminar)
            contexto.SaveChanges()

            respuesta = New RespuestaGenerica
            respuesta.exito = True
            respuesta.mensaje = "El registro se elimino correctamente"
        Catch ex As Exception
            respuesta = New RespuestaGenerica
            respuesta.exito = False
            respuesta.mensaje = ex.Message.ToString
        End Try
        Return respuesta
    End Function

    'SIM
    Public Function InsertarSIM(sim As SIM) As RespuestaGenerica Implements ISie_services.InsertarSIM
        Dim respuesta As New RespuestaGenerica
        Try
            Dim contexto As New SieEntities
            Dim nuevoSIM As New Sie_SIM

            nuevoSIM.Asignado = sim.asignado
            nuevoSIM.Numero_Telefono = sim.numero_telefono
            nuevoSIM.Numero_Serie = sim.numero_serie
            nuevoSIM.Pin = sim.pin
            nuevoSIM.Punk = sim.punk
            nuevoSIM.Usuario_Creacion = sim.usuario_creacion
            nuevoSIM.Fecha_creacion = Date.Now
            contexto.Sie_SIM.Add(nuevoSIM)
            contexto.SaveChanges()

            respuesta = New RespuestaGenerica
            respuesta.exito = True
            respuesta.mensaje = "El registro se inserto con exito"
        Catch ex As Exception
            respuesta = New RespuestaGenerica
            respuesta.exito = False
            respuesta.mensaje = ex.Message.ToString
        End Try
        Return respuesta
    End Function

    Public Function ModificarSIM(sim As SIM) As RespuestaGenerica Implements ISie_services.ModificarSIM
        Dim respuesta As RespuestaGenerica
        Try
            Dim contexto As New SieEntities
            Dim modificar = contexto.Sie_SIM.Where(Function(p) p.Numero_SIM = sim.numero_sim).SingleOrDefault
            'Dim modificar = (From c In contexto.Sie_Categoria Where c.Numero_Categoria = categoria.numero_categoria Select c).SingleOrDefault
            modificar.Numero_SIM = sim.numero_sim
            modificar.Asignado = sim.asignado
            modificar.Numero_Telefono = sim.numero_telefono
            modificar.Numero_Serie = sim.numero_serie
            modificar.Pin = sim.pin
            modificar.Punk = sim.punk
            modificar.Usuario_Modificacion = sim.usuario_modificacion
            modificar.Fecha_modificacion = Date.Now
            contexto.SaveChanges()

            respuesta = New RespuestaGenerica
            respuesta.exito = True
            respuesta.mensaje = "El registro se modifico correctamente"
        Catch ex As Exception
            respuesta = New RespuestaGenerica
            respuesta.exito = False
            respuesta.mensaje = ex.Message.ToString
        End Try
        Return respuesta
    End Function

    Public Function EliminarSIM(numero_sim As Integer) As RespuestaGenerica Implements ISie_services.EliminarSIM
        Dim respuesta As RespuestaGenerica
        Try
            Dim contexto As New SieEntities
            Dim eliminar = contexto.Sie_SIM.Where(Function(p) p.Numero_SIM = numero_sim).SingleOrDefault
            'Dim modificar = (From c In contexto.Sie_Categoria Where c.Numero_Categoria = categoria.numero_categoria Select c).SingleOrDefault
            contexto.Sie_SIM.Remove(eliminar)
            contexto.SaveChanges()

            respuesta = New RespuestaGenerica
            respuesta.exito = True
            respuesta.mensaje = "El registro se elimino correctamente"
        Catch ex As Exception
            respuesta = New RespuestaGenerica
            respuesta.exito = False
            respuesta.mensaje = ex.Message.ToString
        End Try
        Return respuesta
    End Function

    Public Function ObtenerSIM() As List(Of SIM) Implements ISie_services.ObtenerSIM
        Dim listasim As New List(Of SIM)
        Try
            Dim contexto As New SieEntities
            Dim SIMs = contexto.Sie_SIM
            For Each sim In SIMs
                Dim itemSIM As New SIM
                itemSIM.numero_sim = sim.Numero_SIM
                itemSIM.asignado = sim.Asignado
                itemSIM.numero_telefono = sim.Numero_Telefono
                itemSIM.numero_serie = sim.Numero_Serie
                itemSIM.pin = sim.Pin
                itemSIM.punk = sim.Punk
                itemSIM.fecha_creacion = sim.Fecha_creacion
                itemSIM.usuario_creacion = sim.Usuario_Creacion
                itemSIM.fecha_modificacion = sim.Fecha_modificacion
                itemSIM.usuario_modificacion = sim.Usuario_Modificacion
                listasim.Add(itemSIM)
            Next
        Catch ex As Exception

        End Try
        Return listasim
    End Function

    'Otros
    Public Function ObtenerCategoriaPorNombre(codigo As Integer) As String Implements ISie_services.ObtenerCategoriaPorNombre
        Dim nombre As String
        Try
            Dim contexto As New SieEntities
            Dim registro = (From t In contexto.Sie_Equipo_Categoria Where t.Numero_Categoria.Equals(codigo) Select t).FirstOrDefault
            If Not IsNothing(registro) Then
                nombre = registro.Categoria
            End If
        Catch ex As Exception

        End Try
        Return nombre
    End Function

    Public Function ObtenerCategoriaPorParametro(numero_categoria As Integer) As List(Of Categoria) Implements ISie_services.ObtenerCategoriaPorParametro
        Dim listaDepartamento As New List(Of Categoria)
        Try
            Dim contexto As New SieEntities
            Dim registro = (From t In contexto.Sie_Equipo_Categoria Where t.Numero_Categoria.Equals(numero_categoria) Select t).FirstOrDefault
            Dim Departamentos = registro
            Dim itemDepartamento As New Categoria
            itemDepartamento.numero_categoria = Departamentos.Numero_Categoria
            itemDepartamento.categoria = Departamentos.Categoria
            listaDepartamento.Add(itemDepartamento)

        Catch ex As Exception

        End Try
        Return listaDepartamento
    End Function

    Public Function ISie_services_obtenerNumero(serviceTag As String) As Object Implements ISie_services.obtenerNumero
        Dim numero As Integer
        Try
            Dim contexto As New SieEntities
            Dim registro = (From t In contexto.Sie_Equipo Where t.Service_Tag = serviceTag Select t).FirstOrDefault
            If Not IsNothing(registro) Then
                numero = registro.Numero_Equipo
            End If
        Catch ex As Exception

        End Try
        Return numero
    End Function


End Class
